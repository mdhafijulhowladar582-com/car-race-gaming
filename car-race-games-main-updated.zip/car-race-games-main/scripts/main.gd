extends Node3D

enum GameState { MENU, PAGE, RACE, PAUSED, RESULT }

var game_state: GameState = GameState.MENU
var menu_layer: CanvasLayer
var menu_info_label: Label
var menu_auth_status_label: Label
var pause_button_layer: CanvasLayer
var pause_layer: CanvasLayer
var last_back_msec := 0
# survives reload_current_scene(): NEXT RACE / Restart go straight into a race
static var skip_menu_once := false

var health_bar: ProgressBar
var health_label: Label
var mobile_controls: CanvasLayer
var game_over_overlay: ColorRect
var game_over_title: Label
var restart_button: Button
var race_label: Label
var race_bar: ProgressBar
var finish_overlay: ColorRect
var finish_button: Button
var countdown_label: Label
var timer_label: Label
var position_label: Label
var checkpoint_label: Label
var result_time_label: Label
var mode_overlay: ColorRect
var mode_label: Label
var selected_mode := "quick_race"
var mode_name := "QUICK RACE"
var selected_car := "SPORTS"
var car_label: Label
var customization_label: Label
var selected_color := Color(0.82, 0.025, 0.02)
var selected_wheels := "SPORT"
var upgrade_level := 0
var ai_opponents: Array[Node3D] = []
var ai_count := 1
var ai_racing_offsets := [-3.2, -1.6, 1.6]
var ai_race_progress: Array[float] = []
var ai_last_positions: Array[int] = []
var player_race_position := 1
var ai_lap_progress: Array[int] = []
var ambience_player: AudioStreamPlayer3D
var music_player: AudioStreamPlayer
var race_finished := false
var race_started := false
var race_elapsed := 0.0
var countdown_time := 3.0
var current_checkpoint := 0
var total_checkpoints := 3
var lap := 1
var total_laps := 1
var coins := 0
var xp := 0
var save_path := "user://car_race_save.json"
var total_races := 0
var best_time := 0.0
var achievements: Array[String] = []
var selected_weather := "DAY"
var selected_map := "CITY"
var map_label: Label
var rain_particles: GPUParticles3D
var fog_environment: Environment
var reward_label: Label
var coins_label: Label
var speed_label: Label
var speed_bar: ProgressBar
var mini_progress: ProgressBar
var minimap_canvas: CanvasLayer
var minimap_route: Line2D
var minimap_player_marker: ColorRect
var minimap_ai_markers: Array[ColorRect] = []
var minimap_root: Control
var settings_label: Label
var graphics_quality := "MEDIUM"
var master_volume := 1.0
var steering_sensitivity := 1.0
var vibration_enabled := true
var settings_path := "user://car_race_settings.json"
var leaderboard_label: Label
var leaderboard_entries: Array = []
var local_leaderboard: Array = []
var online_leaderboard_status := "OFFLINE"
var firebase_service: Node
var google_signin: RefCounted
var auth_button: Button
var auth_status_label: Label
var firebase_auth_status := "GUEST"
var firebase_display_name := ""
var global_rank := 0
var career_wins := 0
var career_races := 0
var career_stars := 0
var career_reward_multiplier := 1.0
var achievements_overlay: ColorRect
var loading_overlay: ColorRect
var results_canvas: CanvasLayer

var race_start_z := 15.0
var finish_z := -66.0
var progress_hints := {}
var track_path: Array[Vector3] = []
var track_segment_lengths: Array[float] = []
var track_total_length := 0.0
var player_track_progress := 0.0
var sun_light: DirectionalLight3D
var sky_fill_light: DirectionalLight3D
var lighting_tuning := 1.0

func _load_progress() -> void:
    var file := FileAccess.open(save_path, FileAccess.READ)
    if file == null:
        return
    var json := JSON.new()
    var error := json.parse(file.get_as_text())
    if error != OK:
        return
    if not (json.data is Dictionary):
        return
    var data: Dictionary = json.data
    if data.has("coins"):
        coins = int(data["coins"])
    if data.has("xp"):
        xp = int(data["xp"])
    if data.has("total_races"):
        total_races = int(data["total_races"])
    if data.has("best_time"):
        best_time = float(data["best_time"])
    if data.has("selected_map"):
        selected_map = str(data["selected_map"])
    if data.has("selected_weather"):
        selected_weather = str(data["selected_weather"])
    if data.has("selected_car"):
        selected_car = str(data["selected_car"])
    if data.has("selected_color"):
        selected_color = Color(str(data["selected_color"]))
    if data.has("selected_wheels"):
        selected_wheels = str(data["selected_wheels"])
    if data.has("upgrade_level"):
        upgrade_level = clampi(int(data["upgrade_level"]), 0, 3)
    if data.has("achievements") and data["achievements"] is Array:
        achievements.assign(data["achievements"])
    if data.has("local_leaderboard") and data["local_leaderboard"] is Array:
        local_leaderboard = Array(data["local_leaderboard"])
        local_leaderboard.sort_custom(func(a, b) -> bool:
            return _leaderboard_time_value(a) < _leaderboard_time_value(b))

func _save_progress() -> void:
    var data := {
        "coins": coins,
        "xp": xp,
        "total_races": total_races,
        "best_time": best_time,
        "selected_map": selected_map,
        "selected_weather": selected_weather,
        "selected_car": selected_car,
        "selected_color": selected_color.to_html(false),
        "selected_wheels": selected_wheels,
        "upgrade_level": upgrade_level,
        "achievements": achievements,
        "local_leaderboard": local_leaderboard
    }
    var file := FileAccess.open(save_path, FileAccess.WRITE)
    if file:
        file.store_string(JSON.stringify(data))

func _apply_master_volume() -> void:
    AudioServer.set_bus_volume_db(0, linear_to_db(maxf(master_volume, 0.001)))

func _load_settings() -> void:
    var file := FileAccess.open(settings_path, FileAccess.READ)
    if file == null:
        return
    var json := JSON.new()
    var error := json.parse(file.get_as_text())
    if error != OK:
        return
    if not (json.data is Dictionary):
        return
    var data: Dictionary = json.data
    if data.has("graphics_quality"):
        graphics_quality = str(data["graphics_quality"])
    if data.has("master_volume"):
        master_volume = float(data["master_volume"])
    if data.has("steering_sensitivity"):
        steering_sensitivity = float(data["steering_sensitivity"])
    if data.has("vibration_enabled"):
        vibration_enabled = bool(data["vibration_enabled"])
    _apply_master_volume()

var hud_root: Control
var hud_left: VBoxContainer
var hud_top_bar: HBoxContainer
var hud_center: VBoxContainer
var hud_right: VBoxContainer
var hud_bottom: VBoxContainer
var countdown_hide_timer := -1.0

func _ensure_hud() -> void:
    if hud_root and is_instance_valid(hud_root):
        return
    var layer := CanvasLayer.new()
    layer.name = "HudLayer"
    layer.layer = -1
    add_child(layer)
    hud_root = Control.new()
    hud_root.set_anchors_preset(Control.PRESET_FULL_RECT)
    hud_root.mouse_filter = Control.MOUSE_FILTER_IGNORE
    layer.add_child(hud_root)

    hud_left = _make_hud_box(Control.PRESET_TOP_LEFT, Vector2(14.0, 10.0))
    hud_left.add_theme_constant_override("separation", 2)
    hud_top_bar = HBoxContainer.new()
    hud_top_bar.mouse_filter = Control.MOUSE_FILTER_IGNORE
    hud_top_bar.add_theme_constant_override("separation", 8)
    hud_top_bar.set_anchors_preset(Control.PRESET_CENTER_TOP)
    hud_top_bar.grow_horizontal = Control.GROW_DIRECTION_BOTH
    hud_top_bar.offset_top = 10.0
    hud_root.add_child(hud_top_bar)

    hud_center = VBoxContainer.new()
    hud_center.mouse_filter = Control.MOUSE_FILTER_IGNORE
    hud_center.alignment = BoxContainer.ALIGNMENT_BEGIN
    hud_center.add_theme_constant_override("separation", 2)
    hud_center.set_anchors_preset(Control.PRESET_CENTER_TOP)
    hud_center.grow_horizontal = Control.GROW_DIRECTION_BOTH
    hud_center.offset_top = 66.0
    hud_root.add_child(hud_center)

    hud_right = _make_hud_box(Control.PRESET_TOP_RIGHT, Vector2(-14.0, 10.0))
    hud_right.grow_horizontal = Control.GROW_DIRECTION_BEGIN

    hud_bottom = VBoxContainer.new()
    hud_bottom.mouse_filter = Control.MOUSE_FILTER_IGNORE
    hud_bottom.add_theme_constant_override("separation", 4)
    hud_bottom.set_anchors_preset(Control.PRESET_CENTER_BOTTOM)
    hud_bottom.grow_horizontal = Control.GROW_DIRECTION_BOTH
    hud_bottom.grow_vertical = Control.GROW_DIRECTION_BEGIN
    hud_bottom.offset_bottom = -14.0
    hud_root.add_child(hud_bottom)

func _make_hud_box(preset: Control.LayoutPreset, offset: Vector2) -> VBoxContainer:
    var box := VBoxContainer.new()
    box.mouse_filter = Control.MOUSE_FILTER_IGNORE
    box.set_anchors_preset(preset)
    if offset.x < 0.0:
        box.offset_left = offset.x
        box.offset_right = offset.x
    else:
        box.offset_left = offset.x
    box.offset_top = offset.y
    hud_root.add_child(box)
    return box

func _hud_label(text_value: String, font_size: int = 18) -> Label:
    var label := Label.new()
    label.text = text_value
    label.mouse_filter = Control.MOUSE_FILTER_IGNORE
    label.add_theme_font_size_override("font_size", font_size)
    label.add_theme_color_override("font_color", Color(1, 1, 1, 1))
    label.add_theme_color_override("font_outline_color", Color(0, 0, 0, 0.85))
    label.add_theme_constant_override("outline_size", 5)
    return label

func _hud_button(text_value: String, callback: Callable) -> Button:
    _ensure_hud()
    var button := Button.new()
    button.text = text_value
    button.custom_minimum_size = Vector2(0.0, 46.0)
    button.add_theme_font_size_override("font_size", 16)
    button.pressed.connect(callback)
    hud_top_bar.add_child(button)
    return button

func _center_overlay(node: Control, overlay_size: Vector2) -> void:
    var view_size := get_viewport().get_visible_rect().size
    overlay_size.x = minf(overlay_size.x, view_size.x - 24.0)
    overlay_size.y = minf(overlay_size.y, view_size.y - 24.0)
    node.size = overlay_size
    node.position = ((view_size - overlay_size) * 0.5).floor()

func _ready() -> void:
    _load_progress()
    _load_settings()
    _apply_selected_car_to_player()
    _build_environment()
    track_path = _get_map_track_path()
    _rebuild_track_progress_cache()
    _build_environment_scenery()
    _build_high_quality_environment()
    _build_ambience_audio()
    _build_music_system()
    _build_mobile_controls()
    _build_health_hud()
    _build_race_system()
    _build_minimap()
    _build_pause_ui()
    _build_ai_opponents()
    _build_game_over_ui()
    _build_mode_select()
    _apply_professional_lighting(selected_weather)
    _apply_weather(selected_weather)
    _apply_map(selected_map)
    _build_rewards_hud()
    _build_professional_mobile_hud()
    _build_auth_ui()
    _setup_firebase_service()
    _update_map_label()
    _update_rewards_hud()
    _update_ai_racing(0.0)

    var car := get_node_or_null("PlayerCar")
    if car:
        car.health_changed.connect(_on_health_changed)
        car.game_over.connect(_on_game_over)
        _on_health_changed(car.health, car.max_health)

    var back_listener := BackListener.new()
    back_listener.process_mode = Node.PROCESS_MODE_ALWAYS
    add_child(back_listener)
    back_listener.back_pressed.connect(_handle_back)

    _enter_menu_state()
    if skip_menu_once:
        skip_menu_once = false
        _start_race()

# --- Game state (step 1) -----------------------------------------------------

func _enter_menu_state() -> void:
    game_state = GameState.MENU
    race_started = false
    race_finished = false
    race_elapsed = 0.0
    countdown_time = 3.0
    countdown_hide_timer = -1.0
    if countdown_label:
        countdown_label.visible = false
    var car := get_node_or_null("PlayerCar")
    if car:
        car.controls_locked = true
        car.speed = 0.0
        car.velocity = Vector3.ZERO
    for ai in ai_opponents:
        if is_instance_valid(ai):
            ai.race_active = false
    _build_main_menu()
    menu_layer.visible = true
    _refresh_menu_info()
    _update_auth_ui()
    _set_race_ui_visible(false)

func _start_race() -> void:
    if game_state == GameState.RACE:
        return
    race_started = false
    race_finished = false
    race_elapsed = 0.0
    countdown_time = 3.0
    countdown_hide_timer = -1.0
    if countdown_label:
        countdown_label.text = "3"
        countdown_label.visible = true
    var car := get_node_or_null("PlayerCar")
    if car:
        car.controls_locked = true
        car.speed = 0.0
        car.velocity = Vector3.ZERO
    for ai in ai_opponents:
        if is_instance_valid(ai):
            ai.race_active = false
    if menu_layer and is_instance_valid(menu_layer):
        menu_layer.visible = false
    _set_race_ui_visible(true)
    game_state = GameState.RACE

# --- Main menu (step 2) ------------------------------------------------------

func _set_race_ui_visible(value: bool) -> void:
    if hud_root:
        hud_root.visible = value
    if mobile_controls:
        mobile_controls.visible = value
    if minimap_canvas:
        minimap_canvas.visible = value
    if pause_button_layer:
        pause_button_layer.visible = value

func _build_main_menu() -> void:
    if menu_layer and is_instance_valid(menu_layer):
        return
    menu_layer = CanvasLayer.new()
    menu_layer.name = "MainMenuLayer"
    menu_layer.layer = 30
    add_child(menu_layer)

    var bg := ColorRect.new()
    bg.set_anchors_preset(Control.PRESET_FULL_RECT)
    bg.color = Color(0.02, 0.025, 0.04, 0.78)
    menu_layer.add_child(bg)

    var center := CenterContainer.new()
    center.set_anchors_preset(Control.PRESET_FULL_RECT)
    bg.add_child(center)

    var box := VBoxContainer.new()
    box.add_theme_constant_override("separation", 14)
    center.add_child(box)

    var title := Label.new()
    title.text = "CAR RACE"
    title.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
    title.add_theme_font_size_override("font_size", 56)
    box.add_child(title)

    menu_info_label = Label.new()
    menu_info_label.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
    menu_info_label.add_theme_font_size_override("font_size", 20)
    box.add_child(menu_info_label)

    var start := Button.new()
    start.text = "START RACE"
    start.custom_minimum_size = Vector2(460.0, 76.0)
    start.add_theme_font_size_override("font_size", 30)
    start.pressed.connect(_start_race)
    box.add_child(start)

    var grid := GridContainer.new()
    grid.columns = 2
    grid.add_theme_constant_override("h_separation", 14)
    grid.add_theme_constant_override("v_separation", 14)
    box.add_child(grid)

    _menu_button(grid, "CARS", _show_car_selector)
    _menu_button(grid, "MAP", _show_map_selector)
    _menu_button(grid, "WEATHER", _show_weather_selector)
    _menu_button(grid, "SETTINGS", _show_settings)
    _menu_button(grid, "LEADERBOARD", _show_leaderboard)
    auth_button = _menu_button(grid, "GOOGLE LOGIN", _on_auth_button_pressed)

    menu_auth_status_label = Label.new()
    menu_auth_status_label.text = "GUEST MODE"
    menu_auth_status_label.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
    menu_auth_status_label.add_theme_font_size_override("font_size", 16)
    box.add_child(menu_auth_status_label)

func _menu_button(parent: Control, text_value: String, callback: Callable) -> Button:
    var button := Button.new()
    button.text = text_value
    button.custom_minimum_size = Vector2(223.0, 56.0)
    button.add_theme_font_size_override("font_size", 20)
    button.pressed.connect(callback)
    parent.add_child(button)
    return button

func _refresh_menu_info() -> void:
    if menu_info_label:
        menu_info_label.text = "%s  |  %s  |  %s" % [selected_map, selected_weather, selected_car]

# --- Full-screen pages (step 3) ----------------------------------------------

var page_layer: CanvasLayer

# Opens an empty full-screen page (BACK + title on top, scrollable content below)
# and returns the content box. Only works from the main menu.
func _open_page(title_text: String) -> VBoxContainer:
    if game_state != GameState.MENU:
        return null
    _free_page()
    game_state = GameState.PAGE
    if menu_layer and is_instance_valid(menu_layer):
        menu_layer.visible = false

    page_layer = CanvasLayer.new()
    page_layer.name = "PageLayer"
    page_layer.layer = 40
    add_child(page_layer)

    var bg := ColorRect.new()
    bg.set_anchors_preset(Control.PRESET_FULL_RECT)
    bg.color = Color(0.03, 0.04, 0.07, 0.97)
    page_layer.add_child(bg)

    var margin := MarginContainer.new()
    margin.set_anchors_preset(Control.PRESET_FULL_RECT)
    margin.add_theme_constant_override("margin_left", 24)
    margin.add_theme_constant_override("margin_right", 24)
    margin.add_theme_constant_override("margin_top", 16)
    margin.add_theme_constant_override("margin_bottom", 16)
    bg.add_child(margin)

    var root := VBoxContainer.new()
    root.add_theme_constant_override("separation", 12)
    margin.add_child(root)

    var header := HBoxContainer.new()
    header.add_theme_constant_override("separation", 16)
    root.add_child(header)

    var back := Button.new()
    back.text = "< BACK"
    back.custom_minimum_size = Vector2(150.0, 56.0)
    back.add_theme_font_size_override("font_size", 22)
    back.pressed.connect(_close_page)
    header.add_child(back)

    var title := Label.new()
    title.text = title_text
    title.size_flags_horizontal = Control.SIZE_EXPAND_FILL
    title.vertical_alignment = VERTICAL_ALIGNMENT_CENTER
    title.add_theme_font_size_override("font_size", 32)
    header.add_child(title)

    root.add_child(HSeparator.new())

    var scroll := ScrollContainer.new()
    scroll.size_flags_vertical = Control.SIZE_EXPAND_FILL
    scroll.horizontal_scroll_mode = ScrollContainer.SCROLL_MODE_DISABLED
    root.add_child(scroll)

    var content := VBoxContainer.new()
    content.size_flags_horizontal = Control.SIZE_EXPAND_FILL
    content.add_theme_constant_override("separation", 14)
    scroll.add_child(content)
    return content

func _close_page() -> void:
    _free_page()
    if game_state != GameState.PAGE:
        return
    game_state = GameState.MENU
    _refresh_menu_info()
    if menu_layer and is_instance_valid(menu_layer):
        menu_layer.visible = true

func _free_page() -> void:
    if page_layer and is_instance_valid(page_layer):
        page_layer.queue_free()
    page_layer = null
    # labels that lived on the page are gone with it
    settings_label = null
    leaderboard_label = null
    car_label = null
    customization_label = null

# --- Pause, restart, back button (step 5) ------------------------------------

# Listens for Esc / ui_cancel even while the tree is paused.
class BackListener extends Node:
    signal back_pressed
    func _unhandled_input(event: InputEvent) -> void:
        if event.is_action_pressed("ui_cancel"):
            back_pressed.emit()
            get_viewport().set_input_as_handled()

func _notification(what: int) -> void:
    # Android phone BACK button
    if what == NOTIFICATION_WM_GO_BACK_REQUEST:
        _handle_back()

func _handle_back() -> void:
    # Android can report BACK in two ways at once; ignore the duplicate
    var now := Time.get_ticks_msec()
    if now - last_back_msec < 300:
        return
    last_back_msec = now
    match game_state:
        GameState.PAGE:
            _close_page()
        GameState.RACE:
            var car := get_node_or_null("PlayerCar")
            if car and car.is_game_over:
                _go_main_menu()
            else:
                _pause_race()
        GameState.PAUSED:
            _resume_race()
        GameState.RESULT:
            _go_main_menu()
        GameState.MENU:
            get_tree().quit()

func _build_pause_ui() -> void:
    # small PAUSE button, top-right corner (only visible during a race)
    pause_button_layer = CanvasLayer.new()
    pause_button_layer.name = "PauseButtonLayer"
    pause_button_layer.layer = 25
    add_child(pause_button_layer)
    var pause_button := Button.new()
    pause_button.text = "PAUSE"
    pause_button.set_anchors_preset(Control.PRESET_TOP_RIGHT)
    pause_button.offset_left = -134.0
    pause_button.offset_right = -14.0
    pause_button.offset_top = 10.0
    pause_button.offset_bottom = 56.0
    pause_button.add_theme_font_size_override("font_size", 18)
    pause_button.pressed.connect(_pause_race)
    pause_button_layer.add_child(pause_button)

    # pause menu (works while the game tree is paused)
    pause_layer = CanvasLayer.new()
    pause_layer.name = "PauseLayer"
    pause_layer.layer = 50
    pause_layer.process_mode = Node.PROCESS_MODE_ALWAYS
    pause_layer.visible = false
    add_child(pause_layer)

    var bg := ColorRect.new()
    bg.set_anchors_preset(Control.PRESET_FULL_RECT)
    bg.color = Color(0.0, 0.0, 0.0, 0.72)
    pause_layer.add_child(bg)

    var center := CenterContainer.new()
    center.set_anchors_preset(Control.PRESET_FULL_RECT)
    bg.add_child(center)

    var box := VBoxContainer.new()
    box.add_theme_constant_override("separation", 14)
    center.add_child(box)

    var title := Label.new()
    title.text = "PAUSED"
    title.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
    title.add_theme_font_size_override("font_size", 48)
    box.add_child(title)

    for item in [["RESUME", _resume_race], ["RESTART", _restart_race], ["MAIN MENU", _go_main_menu]]:
        var button := Button.new()
        button.text = item[0]
        button.custom_minimum_size = Vector2(320.0, 64.0)
        button.add_theme_font_size_override("font_size", 26)
        button.pressed.connect(item[1])
        box.add_child(button)

func _release_touch_actions() -> void:
    for action_name in ["steer_left", "steer_right", "brake", "accelerate"]:
        Input.action_release(action_name)

func _rebuild_mobile_controls() -> void:
    # fresh touch buttons, so a finger lifted during pause can't leave GO stuck
    if mobile_controls and is_instance_valid(mobile_controls):
        mobile_controls.queue_free()
    _build_mobile_controls()

func _pause_race() -> void:
    if game_state != GameState.RACE or race_finished:
        return
    game_state = GameState.PAUSED
    _release_touch_actions()
    get_tree().paused = true
    if pause_layer:
        pause_layer.visible = true

func _resume_race() -> void:
    if game_state != GameState.PAUSED:
        return
    if pause_layer:
        pause_layer.visible = false
    get_tree().paused = false
    _rebuild_mobile_controls()
    game_state = GameState.RACE

# Puts car, AI and HUD back to a fresh start without reloading the scene
# (so Google login and the chosen map/weather stay as they are).
func _reset_race_state() -> void:
    get_tree().paused = false
    _release_touch_actions()
    if pause_layer:
        pause_layer.visible = false
    if game_over_overlay:
        game_over_overlay.visible = false
    if results_canvas and is_instance_valid(results_canvas):
        results_canvas.queue_free()
        results_canvas = null
    var car := get_node_or_null("PlayerCar")
    if car and car.has_method("reset_for_new_race"):
        car.reset_for_new_race()
    _sync_race_start_to_map()
    _rebuild_mobile_controls()
    game_state = GameState.MENU
    race_started = false
    race_finished = false
    race_elapsed = 0.0
    current_checkpoint = 0
    player_race_position = 1
    player_track_progress = 0.0
    if timer_label:
        timer_label.text = "TIME 00:00.00"
    if position_label:
        position_label.text = "POSITION 1/%d" % (ai_opponents.size() + 1)
    if race_bar:
        race_bar.value = 0.0
    if race_label:
        race_label.text = "READY"
    _update_ai_racing(0.0)

func _restart_race() -> void:
    _reset_race_state()
    _start_race()

func _go_main_menu() -> void:
    _reset_race_state()
    _enter_menu_state()

func _page_label(parent: Control, text_value: String, font_size: int = 22) -> Label:
    var label := Label.new()
    label.text = text_value
    label.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
    label.size_flags_horizontal = Control.SIZE_EXPAND_FILL
    label.add_theme_font_size_override("font_size", font_size)
    parent.add_child(label)
    return label

func _page_button(parent: Control, text_value: String, callback: Callable) -> Button:
    var button := Button.new()
    button.text = text_value
    button.custom_minimum_size = Vector2(0.0, 68.0)
    button.size_flags_horizontal = Control.SIZE_EXPAND_FILL
    button.add_theme_font_size_override("font_size", 24)
    button.pressed.connect(callback)
    parent.add_child(button)
    return button

func _page_grid(parent: Control, columns: int) -> GridContainer:
    var grid := GridContainer.new()
    grid.columns = columns
    grid.size_flags_horizontal = Control.SIZE_EXPAND_FILL
    grid.add_theme_constant_override("h_separation", 12)
    grid.add_theme_constant_override("v_separation", 12)
    parent.add_child(grid)
    return grid

func _physics_process(delta: float) -> void:
    _update_minimap()
    var car := get_node_or_null("PlayerCar")
    if car and speed_label:
        var kmh: float = absf(car.speed) * 3.6
        speed_label.text = "%d KM/H" % int(round(kmh))
        if speed_bar:
            speed_bar.value = kmh
    if countdown_hide_timer > 0.0:
        countdown_hide_timer -= delta
        if countdown_hide_timer <= 0.0 and countdown_label:
            countdown_label.visible = false
    if game_state == GameState.MENU or game_state == GameState.PAGE or game_state == GameState.PAUSED:
        return
    if not car or race_finished:
        return

    if not race_started:
        countdown_time = maxf(countdown_time - delta, 0.0)
        car.speed = 0.0
        car.velocity = Vector3.ZERO
        car.controls_locked = true
        if countdown_label:
            countdown_label.text = str(ceili(countdown_time)) if countdown_time > 0.0 else "GO!"
        if countdown_time <= 0.0:
            race_started = true
            race_elapsed = 0.0
            countdown_hide_timer = 0.9
            car.controls_locked = false
            for ai in ai_opponents:
                if is_instance_valid(ai) and ai.has_method("start_race"):
                    ai.start_race()
        return

    race_elapsed += delta
    _update_ai_racing(delta)
    var progress := _get_track_progress(car.global_position, 0)
    player_track_progress = progress
    current_checkpoint = clampi(int(floor(progress * total_checkpoints)), 0, total_checkpoints)

    if race_bar:
        race_bar.value = progress
    if timer_label:
        var minutes := int(race_elapsed / 60.0)
        var seconds := fmod(race_elapsed, 60.0)
        timer_label.text = "TIME %02d:%05.2f" % [minutes, seconds]
    if checkpoint_label:
        checkpoint_label.text = "CHECKPOINT %d/%d" % [current_checkpoint, total_checkpoints]

    player_race_position = 1
    for ai in ai_opponents:
        if is_instance_valid(ai) and _get_track_progress(ai.global_position, ai.get_instance_id()) > player_track_progress:
            player_race_position += 1
    if position_label:
        position_label.text = "POSITION %d/%d" % [player_race_position, ai_opponents.size() + 1]

    if progress >= 1.0:
        _finish_race()

func _build_mobile_controls() -> void:
    mobile_controls = CanvasLayer.new()
    mobile_controls.layer = 15
    add_child(mobile_controls)

    var root := Control.new()
    root.set_anchors_preset(Control.PRESET_FULL_RECT)
    root.mouse_filter = Control.MOUSE_FILTER_IGNORE
    mobile_controls.add_child(root)

    var hint := Label.new()
    hint.text = ""
    hint.visible = false

    _add_touch_button(root, "LEFT", "steer_left", true, 18.0)
    _add_touch_button(root, "RIGHT", "steer_right", true, 138.0)
    _add_touch_button(root, "BRAKE", "brake", false, 138.0)
    _add_touch_button(root, "GO", "accelerate", false, 18.0)

func _add_touch_button(parent: Control, label_text: String, action_name: String, left_side: bool, bottom_offset: float) -> void:
    var button := TouchScreenButton.new()
    button.name = "Touch_%s" % action_name
    button.action = action_name
    button.passby_press = true
    var shape := RectangleShape2D.new()
    shape.size = Vector2(100.0, 82.0)
    button.shape = shape
    button.shape_centered = true
    var viewport_size := get_viewport().get_visible_rect().size
    if left_side:
        button.position = Vector2(bottom_offset + 50.0, viewport_size.y - 100.0)
    else:
        button.position = Vector2(viewport_size.x - bottom_offset - 50.0, viewport_size.y - 100.0)
    var label := Label.new()
    label.text = label_text
    label.position = Vector2(-50.0, -41.0)
    label.size = Vector2(100.0, 82.0)
    label.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
    label.vertical_alignment = VERTICAL_ALIGNMENT_CENTER
    label.mouse_filter = Control.MOUSE_FILTER_IGNORE
    label.add_theme_font_size_override("font_size", 18)
    button.add_child(label)
    parent.add_child(button)

func _finish_race() -> void:
    if race_finished:
        return
    var score_valid := race_started and race_elapsed >= 3.0 and current_checkpoint >= total_checkpoints
    race_finished = true
    race_started = false
    game_state = GameState.RESULT
    if pause_button_layer:
        pause_button_layer.visible = false
    var car := get_node_or_null("PlayerCar")
    if car:
        car.controls_locked = true
        car.speed = 0.0
        car.velocity = Vector3.ZERO
    for ai in ai_opponents:
        if is_instance_valid(ai):
            ai.race_active = false

    total_races += 1
    var reward_coins: int = max(10, 60 - (player_race_position - 1) * 10)
    var reward_xp: int = max(25, 100 - (player_race_position - 1) * 15)
    coins += reward_coins
    xp += reward_xp
    if player_race_position == 1:
        career_wins += 1
        career_stars += 3
    elif player_race_position == 2:
        career_stars += 2
    elif player_race_position == 3:
        career_stars += 1
    career_races += 1
    if score_valid and (best_time <= 0.0 or race_elapsed < best_time):
        best_time = race_elapsed
    _save_progress()
    _update_rewards_hud()
    if race_label:
        race_label.text = "FINISH"
    _record_local_result()
    if score_valid and firebase_auth_status == "SIGNED_IN" and firebase_service:
        global_rank = 0
        firebase_service.save_best_score(race_elapsed, selected_map, selected_car)
    _show_race_results(reward_coins, reward_xp)

func _record_local_result() -> void:
    var entry := {
        "name": firebase_display_name if firebase_auth_status == "SIGNED_IN" and not firebase_display_name.is_empty() else "GUEST",
        "time": race_elapsed,
        "map": selected_map,
        "car": selected_car,
        "local": true
    }
    local_leaderboard.append(entry)
    local_leaderboard.sort_custom(func(a, b) -> bool:
        return _leaderboard_time_value(a) < _leaderboard_time_value(b))
    if local_leaderboard.size() > 20:
        local_leaderboard.resize(20)
    _save_progress()

func _show_race_results(reward_coins: int, reward_xp: int) -> void:
    if results_canvas and is_instance_valid(results_canvas):
        results_canvas.queue_free()
    results_canvas = CanvasLayer.new()
    add_child(results_canvas)

    var overlay := ColorRect.new()
    overlay.color = Color(0.0, 0.0, 0.0, 0.78)
    overlay.set_anchors_preset(Control.PRESET_FULL_RECT)
    results_canvas.add_child(overlay)

    var res_box := VBoxContainer.new()
    res_box.alignment = BoxContainer.ALIGNMENT_CENTER
    res_box.add_theme_constant_override("separation", 18)
    res_box.set_anchors_preset(Control.PRESET_CENTER)
    res_box.grow_horizontal = Control.GROW_DIRECTION_BOTH
    res_box.grow_vertical = Control.GROW_DIRECTION_BOTH
    overlay.add_child(res_box)
    var title := Label.new()
    title.text = "RACE COMPLETE"
    title.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
    title.add_theme_font_size_override("font_size", 42)
    res_box.add_child(title)

    result_time_label = Label.new()
    var minutes := int(race_elapsed / 60.0)
    var seconds := fmod(race_elapsed, 60.0)
    result_time_label.text = "TIME %02d:%05.2f\nPOSITION %d/%d\n+%d COINS\n+%d XP" % [minutes, seconds, player_race_position, ai_opponents.size() + 1, reward_coins, reward_xp]
    result_time_label.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
    result_time_label.add_theme_font_size_override("font_size", 24)
    res_box.add_child(result_time_label)

    var restart := Button.new()
    restart.text = "NEXT RACE"
    restart.custom_minimum_size = Vector2(260.0, 60.0)
    restart.pressed.connect(_restart_race)
    res_box.add_child(restart)

    var menu_button := Button.new()
    menu_button.text = "MAIN MENU"
    menu_button.custom_minimum_size = Vector2(260.0, 60.0)
    menu_button.pressed.connect(_go_main_menu)
    res_box.add_child(menu_button)

func _build_health_hud() -> void:
    _ensure_hud()
    health_bar = ProgressBar.new()
    health_bar.min_value = 0.0
    health_bar.max_value = 100.0
    health_bar.value = 100.0
    health_bar.show_percentage = false
    health_bar.custom_minimum_size = Vector2(200.0, 14.0)
    health_bar.mouse_filter = Control.MOUSE_FILTER_IGNORE
    hud_left.add_child(health_bar)
    health_label = _hud_label("Health 100%", 16)
    hud_left.add_child(health_label)

func _build_race_system() -> void:
    _ensure_hud()
    map_label = _hud_label("MAP: %s" % selected_map, 16)
    map_label.visible = false  # step 4: not shown during the race
    hud_left.add_child(map_label)
    position_label = _hud_label("POSITION 1/4", 18)
    hud_left.add_child(position_label)
    checkpoint_label = _hud_label("CHECKPOINT 0/3", 18)
    checkpoint_label.visible = false  # step 4
    hud_left.add_child(checkpoint_label)
    auth_status_label = _hud_label("GUEST MODE", 13)
    auth_status_label.visible = false  # step 4: login status lives in the menu
    hud_left.add_child(auth_status_label)

    race_label = _hud_label("READY", 22)
    race_label.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
    race_label.visible = false  # step 4
    hud_center.add_child(race_label)
    timer_label = _hud_label("TIME 00:00.00", 20)
    timer_label.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
    hud_center.add_child(timer_label)
    race_bar = ProgressBar.new()
    race_bar.min_value = 0.0
    race_bar.max_value = 1.0
    race_bar.value = 0.0
    race_bar.show_percentage = false
    race_bar.custom_minimum_size = Vector2(320.0, 12.0)
    race_bar.mouse_filter = Control.MOUSE_FILTER_IGNORE
    race_bar.visible = false  # step 4
    hud_center.add_child(race_bar)

    countdown_label = _hud_label("3", 96)
    countdown_label.add_theme_constant_override("outline_size", 10)
    countdown_label.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
    countdown_label.set_anchors_preset(Control.PRESET_CENTER)
    countdown_label.grow_horizontal = Control.GROW_DIRECTION_BOTH
    countdown_label.grow_vertical = Control.GROW_DIRECTION_BOTH
    countdown_label.offset_top = -170.0
    hud_root.add_child(countdown_label)

func _build_minimap() -> void:
    minimap_canvas = CanvasLayer.new()
    minimap_canvas.layer = 20
    add_child(minimap_canvas)

    var panel := ColorRect.new()
    panel.name = "MinimapPanel"
    panel.set_anchors_preset(Control.PRESET_TOP_RIGHT)
    panel.offset_left = -164.0
    panel.offset_right = -14.0
    panel.offset_top = 64.0
    panel.offset_bottom = 174.0
    panel.mouse_filter = Control.MOUSE_FILTER_IGNORE
    panel.color = Color(0.015, 0.02, 0.035, 0.7)
    minimap_canvas.add_child(panel)

    minimap_root = Control.new()
    minimap_root.position = Vector2(6.0, 6.0)
    minimap_root.size = Vector2(138.0, 98.0)
    minimap_root.mouse_filter = Control.MOUSE_FILTER_IGNORE
    panel.add_child(minimap_root)

    minimap_route = Line2D.new()
    minimap_route.width = 4.0
    minimap_route.closed = false
    minimap_root.add_child(minimap_route)

    minimap_player_marker = ColorRect.new()
    minimap_player_marker.size = Vector2(10.0, 10.0)
    minimap_player_marker.color = Color(1.0, 0.82, 0.08, 1.0)
    minimap_root.add_child(minimap_player_marker)

    _update_minimap_route()

func _update_minimap_route() -> void:
    if not minimap_route or track_path.is_empty():
        return

    var min_x := INF
    var max_x := -INF
    var min_z := INF
    var max_z := -INF
    for point in track_path:
        min_x = minf(min_x, point.x)
        max_x = maxf(max_x, point.x)
        min_z = minf(min_z, point.z)
        max_z = maxf(max_z, point.z)

    var width := maxf(max_x - min_x, 1.0)
    var depth := maxf(max_z - min_z, 1.0)
    var points := PackedVector2Array()
    var margin := 8.0
    var draw_size := minimap_root.size - Vector2.ONE * margin * 2.0

    for point in track_path:
        var x := ((point.x - min_x) / width) * draw_size.x + margin
        var y := ((max_z - point.z) / depth) * draw_size.y + margin
        points.append(Vector2(x, y))

    minimap_route.points = points

    for marker in minimap_ai_markers:
        if is_instance_valid(marker):
            marker.queue_free()
    minimap_ai_markers.clear()

    for i in range(ai_opponents.size()):
        var marker := ColorRect.new()
        marker.size = Vector2(8.0, 8.0)
        marker.color = Color(0.25, 0.55, 1.0, 1.0)
        minimap_root.add_child(marker)
        minimap_ai_markers.append(marker)

    _update_minimap()

func _update_minimap() -> void:
    if not minimap_root or track_path.is_empty():
        return

    var min_x := INF
    var max_x := -INF
    var min_z := INF
    var max_z := -INF
    for point in track_path:
        min_x = minf(min_x, point.x)
        max_x = maxf(max_x, point.x)
        min_z = minf(min_z, point.z)
        max_z = maxf(max_z, point.z)

    var width := maxf(max_x - min_x, 1.0)
    var depth := maxf(max_z - min_z, 1.0)
    var margin := 8.0
    var draw_size := minimap_root.size - Vector2.ONE * margin * 2.0

    var car := get_node_or_null("PlayerCar")
    if car and minimap_player_marker:
        var px: float = ((car.global_position.x - min_x) / width) * draw_size.x + margin
        var py: float = ((max_z - car.global_position.z) / depth) * draw_size.y + margin
        minimap_player_marker.position = Vector2(px - 5.0, py - 5.0)

    for i in range(mini(ai_opponents.size(), minimap_ai_markers.size())):
        var ai := ai_opponents[i]
        if not is_instance_valid(ai):
            continue
        var ax := ((ai.global_position.x - min_x) / width) * draw_size.x + margin
        var ay := ((max_z - ai.global_position.z) / depth) * draw_size.y + margin
        minimap_ai_markers[i].position = Vector2(ax - 4.0, ay - 4.0)

func _build_ai_opponents() -> void:
    if track_path.is_empty():
        return
    var ai_scene := preload("res://scripts/ai_car.gd")
    for i in range(ai_count):
        var ai := CharacterBody3D.new()
        ai.set_script(ai_scene)
        ai.position = Vector3(ai_racing_offsets[i], 1.0, 15.0)
        ai.name = "AiOpponent%s" % (i + 1)
        add_child(ai)
        ai_opponents.append(ai)
        ai.setup(track_path, 0)
        ai.race_active = false
    _update_minimap_route()

func _build_game_over_ui() -> void:
    var go_layer := CanvasLayer.new()
    go_layer.layer = 30
    add_child(go_layer)
    game_over_overlay = ColorRect.new()
    game_over_overlay.color = Color(0.0, 0.0, 0.0, 0.7)
    game_over_overlay.set_anchors_preset(Control.PRESET_FULL_RECT)
    game_over_overlay.visible = false
    go_layer.add_child(game_over_overlay)
    var box := VBoxContainer.new()
    box.alignment = BoxContainer.ALIGNMENT_CENTER
    box.add_theme_constant_override("separation", 24)
    box.set_anchors_preset(Control.PRESET_CENTER)
    box.grow_horizontal = Control.GROW_DIRECTION_BOTH
    box.grow_vertical = Control.GROW_DIRECTION_BOTH
    game_over_overlay.add_child(box)
    game_over_title = Label.new()
    game_over_title.text = "RACE OVER"
    game_over_title.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
    game_over_title.add_theme_font_size_override("font_size", 42)
    box.add_child(game_over_title)
    restart_button = Button.new()
    restart_button.text = "Restart"
    restart_button.custom_minimum_size = Vector2(220.0, 56.0)
    restart_button.pressed.connect(_restart_race)
    box.add_child(restart_button)
    var go_menu_button := Button.new()
    go_menu_button.text = "MAIN MENU"
    go_menu_button.custom_minimum_size = Vector2(220.0, 56.0)
    go_menu_button.pressed.connect(_go_main_menu)
    box.add_child(go_menu_button)

func _build_mode_select() -> void:
    _ensure_hud()
    mode_label = _hud_label(mode_name, 16)
    mode_label.visible = false  # step 4
    hud_left.add_child(mode_label)

func _apply_weather(weather: String) -> void:
    selected_weather = weather
    _save_progress()
    _apply_professional_lighting(selected_weather)

    if rain_particles and is_instance_valid(rain_particles):
        rain_particles.queue_free()
        rain_particles = null

    if selected_weather == "RAIN":
        rain_particles = GPUParticles3D.new()
        rain_particles.name = "RainParticles"
        rain_particles.amount = 900
        rain_particles.lifetime = 1.2
        rain_particles.visibility_aabb = AABB(Vector3(-35.0, 0.0, -80.0), Vector3(70.0, 18.0, 110.0))

        var rain_mesh := QuadMesh.new()
        rain_mesh.size = Vector2(0.035, 1.2)
        var rain_material := StandardMaterial3D.new()
        rain_material.shading_mode = BaseMaterial3D.SHADING_MODE_UNSHADED
        rain_material.transparency = BaseMaterial3D.TRANSPARENCY_ALPHA
        rain_material.albedo_color = Color(0.55, 0.7, 1.0, 0.55)
        rain_mesh.material = rain_material
        rain_particles.draw_pass_1 = rain_mesh

        var process_material := ParticleProcessMaterial.new()
        process_material.emission_shape = ParticleProcessMaterial.EMISSION_SHAPE_BOX
        process_material.emission_box_extents = Vector3(35.0, 1.0, 55.0)
        process_material.direction = Vector3(0.0, -1.0, 0.0)
        process_material.initial_velocity_min = 18.0
        process_material.initial_velocity_max = 26.0
        process_material.gravity = Vector3(0.0, -4.0, 0.0)
        process_material.spread = 4.0
        rain_particles.process_material = process_material
        rain_particles.position = Vector3(0.0, 12.0, -28.0)
        add_child(rain_particles)

    if fog_environment and is_instance_valid(fog_environment):
        fog_environment.fog_enabled = true
        fog_environment.fog_density = 0.012 if selected_weather == "RAIN" else 0.003

func _apply_map(map_name: String) -> void:
    selected_map = map_name
    _save_progress()
    _rebuild_map()
    if map_label:
        map_label.text = "MAP: %s" % selected_map

func _rebuild_map() -> void:
    for child in get_children():
        if child.name.begins_with("CurvedRoad") or child.name == "ApexMarker" or child.name == "MapEnvironment":
            child.queue_free()

    await get_tree().process_frame

    _build_professional_track()
    _build_map_environment()
    _sync_race_start_to_map()
    _update_minimap_route()

func _build_map_environment() -> void:
    var environment_root := Node3D.new()
    environment_root.name = "MapEnvironment"
    add_child(environment_root)

    var material := _make_pbr_material(Color(0.035, 0.11, 0.045), 0.98, 0.0, 3.0, 700 + selected_map.length())

    if selected_map == "DESERT":
        material = _make_pbr_material(Color(0.45, 0.25, 0.08), 0.92, 0.0, 3.0, 711)
        for i in range(16):
            var z := 12.0 - float(i) * 5.5
            _add_map_tree_or_cactus(environment_root, Vector3(-12.0, 0.0, z), false)
            _add_map_tree_or_cactus(environment_root, Vector3(14.0, 0.0, z - 2.0), false)
    elif selected_map == "HIGHWAY":
        material = _make_pbr_material(Color(0.07, 0.08, 0.09), 0.9, 0.05, 3.0, 722)
        for i in range(12):
            var z := 12.0 - float(i) * 7.0
            _add_map_building(environment_root, Vector3(-14.0, 4.0, z), Vector3(6.0, 8.0, 6.0))
            _add_map_building(environment_root, Vector3(16.0, 5.0, z - 3.0), Vector3(7.0, 10.0, 7.0))
    else:
        for i in range(18):
            var z := 13.0 - float(i) * 5.0
            _add_map_tree_or_cactus(environment_root, Vector3(-12.0, 0.0, z), true)
            _add_map_tree_or_cactus(environment_root, Vector3(15.0, 0.0, z - 2.0), true)

func _add_map_tree_or_cactus(parent: Node3D, position: Vector3, tree: bool) -> void:
    var root := Node3D.new()
    root.position = position
    parent.add_child(root)

    var material := _make_material(Color(0.08, 0.25, 0.09) if tree else Color(0.35, 0.5, 0.16), 0.0, 0.9)
    var trunk := MeshInstance3D.new()
    var trunk_mesh := CylinderMesh.new()
    trunk_mesh.top_radius = 0.12 if tree else 0.22
    trunk_mesh.bottom_radius = 0.22 if tree else 0.28
    trunk_mesh.height = 2.6 if tree else 2.2
    trunk.mesh = trunk_mesh
    trunk.position.y = trunk_mesh.height * 0.5
    trunk.material_override = material
    root.add_child(trunk)

    if tree:
        var crown := MeshInstance3D.new()
        var crown_mesh := SphereMesh.new()
        crown_mesh.radius = 1.1
        crown_mesh.height = 2.2
        crown.mesh = crown_mesh
        crown.position.y = 2.9
        crown.material_override = material
        root.add_child(crown)
    else:
        for side in [-1.0, 1.0]:
            var arm := MeshInstance3D.new()
            var arm_mesh := CylinderMesh.new()
            arm_mesh.top_radius = 0.1
            arm_mesh.bottom_radius = 0.14
            arm_mesh.height = 0.9
            arm.mesh = arm_mesh
            arm.position = Vector3(side * 0.42, 1.7, 0.0)
            arm.rotation_degrees.z = side * 65.0
            arm.material_override = material
            root.add_child(arm)

func _add_map_building(parent: Node3D, position: Vector3, size: Vector3) -> void:
    var building := MeshInstance3D.new()
    var mesh := BoxMesh.new()
    mesh.size = size
    building.mesh = mesh
    building.position = position
    building.material_override = _make_material(Color(0.16, 0.18, 0.2), 0.25, 0.75)
    parent.add_child(building)

func _sync_race_start_to_map() -> void:
    if track_path.is_empty():
        return
    race_start_z = track_path[0].z
    finish_z = track_path[track_path.size() - 1].z
    _rebuild_track_progress_cache()
    progress_hints.clear()
    race_finished = false
    race_started = false
    countdown_time = 3.0
    if results_canvas and is_instance_valid(results_canvas):
        results_canvas.queue_free()
        results_canvas = null
    var start_dir := track_path[1] - track_path[0] if track_path.size() > 1 else Vector3(0.0, 0.0, -1.0)
    var start_yaw := atan2(-start_dir.x, -start_dir.z)

    var car := get_node_or_null("PlayerCar")
    if car:
        car.global_position = track_path[0] + Vector3(0.0, 1.0, 0.0)
        car.rotation = Vector3(0.0, start_yaw, 0.0)
        car.velocity = Vector3.ZERO
        car.speed = 0.0
        car.steering = 0.0
        car.controls_locked = true

    for i in range(ai_opponents.size()):
        var ai := ai_opponents[i]
        if not is_instance_valid(ai):
            continue
        if ai.has_method("setup"):
            ai.setup(track_path, 0)
        ai.rotation = Vector3(0.0, start_yaw, 0.0)
        ai.global_position = track_path[0] + Vector3(ai_racing_offsets[i], 1.0, 0.0)
        ai.velocity = Vector3.ZERO
        ai.speed = 0.0
        ai.race_active = false
        ai.finished = false

func _build_rewards_hud() -> void:
    _ensure_hud()
    reward_label = _hud_label("Rewards", 16)
    reward_label.horizontal_alignment = HORIZONTAL_ALIGNMENT_RIGHT
    reward_label.visible = false  # step 4
    hud_right.add_child(reward_label)
    coins_label = null

func _build_professional_mobile_hud() -> void:
    _ensure_hud()
    speed_label = _hud_label("0 KM/H", 20)
    speed_label.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
    hud_bottom.add_child(speed_label)
    speed_bar = ProgressBar.new()
    speed_bar.min_value = 0.0
    speed_bar.max_value = 180.0
    speed_bar.value = 0.0
    speed_bar.show_percentage = false
    speed_bar.custom_minimum_size = Vector2(240.0, 12.0)
    speed_bar.mouse_filter = Control.MOUSE_FILTER_IGNORE
    hud_bottom.add_child(speed_bar)

func _show_weather_selector() -> void:
    var box := _open_page("SELECT WEATHER")
    if box == null:
        return
    for item in ["DAY", "NIGHT", "RAIN"]:
        var weather_name: String = item
        var label := weather_name + ("   (SELECTED)" if weather_name == selected_weather else "")
        _page_button(box, label, func() -> void:
            _apply_weather(weather_name)
            _close_page()
        )

func _show_map_selector() -> void:
    var box := _open_page("SELECT MAP")
    if box == null:
        return
    for item in ["CITY", "HIGHWAY", "DESERT"]:
        var map_name: String = item
        var label := map_name + ("   (SELECTED)" if map_name == selected_map else "")
        _page_button(box, label, func() -> void:
            _apply_map(map_name)
            _close_page()
        )

func _show_settings() -> void:
    var box := _open_page("SETTINGS")
    if box == null:
        return

    settings_label = _page_label(box, "", 24)

    _page_label(box, "Steering Sensitivity", 22)
    var sensitivity_slider := HSlider.new()
    sensitivity_slider.custom_minimum_size = Vector2(0.0, 48.0)
    sensitivity_slider.size_flags_horizontal = Control.SIZE_EXPAND_FILL
    sensitivity_slider.min_value = 0.5
    sensitivity_slider.max_value = 1.8
    sensitivity_slider.step = 0.05
    sensitivity_slider.value = steering_sensitivity
    sensitivity_slider.value_changed.connect(_on_sensitivity_changed)
    box.add_child(sensitivity_slider)

    _page_label(box, "Master Volume", 22)
    var volume_slider := HSlider.new()
    volume_slider.custom_minimum_size = Vector2(0.0, 48.0)
    volume_slider.size_flags_horizontal = Control.SIZE_EXPAND_FILL
    volume_slider.min_value = 0.0
    volume_slider.max_value = 1.0
    volume_slider.step = 0.05
    volume_slider.value = master_volume
    volume_slider.value_changed.connect(_on_master_volume_changed)
    box.add_child(volume_slider)

    _update_settings_label()

func _update_settings_label() -> void:
    if settings_label and is_instance_valid(settings_label):
        settings_label.text = "Sensitivity: %.2f   |   Volume: %d%%   |   Quality: %s" % [steering_sensitivity, int(master_volume * 100.0), graphics_quality]

func _on_sensitivity_changed(value: float) -> void:
    steering_sensitivity = value
    var car := get_node_or_null("PlayerCar")
    if car and "steering_sensitivity" in car:
        car.steering_sensitivity = value
    _save_settings()
    _update_settings_label()

func _on_master_volume_changed(value: float) -> void:
    master_volume = value
    _apply_master_volume()
    _save_settings()
    _update_settings_label()

func _save_settings() -> void:
    var data := {
        "graphics_quality": graphics_quality,
        "master_volume": master_volume,
        "steering_sensitivity": steering_sensitivity,
        "vibration_enabled": vibration_enabled
    }
    var file := FileAccess.open(settings_path, FileAccess.WRITE)
    if file:
        file.store_string(JSON.stringify(data))

func _build_auth_ui() -> void:
    google_signin = preload("res://scripts/google_signin.gd").new()
    google_signin.sign_in_success.connect(_on_google_sign_in_success)
    google_signin.sign_in_failed.connect(_on_google_sign_in_failed)
    google_signin.signed_out.connect(_on_google_signed_out)

    # the GOOGLE LOGIN button now lives in the main menu (_build_main_menu)

func _on_auth_button_pressed() -> void:
    if firebase_auth_status == "SIGNED_IN":
        google_signin.sign_out()
    else:
        google_signin.sign_in()

func _on_google_sign_in_success(id_token: String, _display_name: String, _email: String) -> void:
    if firebase_service:
        firebase_service.sign_in_with_google_id_token(id_token)
    else:
        firebase_auth_status = "AUTH_ERROR"
        _update_auth_ui()

func _on_google_sign_in_failed(message: String) -> void:
    firebase_auth_status = "AUTH_ERROR"
    _update_auth_ui()
    if auth_status_label:
        auth_status_label.text = message.left(24)
    if menu_auth_status_label:
        menu_auth_status_label.text = message.left(24)

func _on_google_signed_out() -> void:
    if firebase_service:
        firebase_service.sign_out()
    else:
        firebase_auth_status = "GUEST"
        _update_auth_ui()

func _update_auth_ui() -> void:
    if not auth_button:
        return
    var status_text := "GUEST MODE"
    if firebase_auth_status == "SIGNED_IN":
        auth_button.text = "LOG OUT"
        status_text = firebase_display_name.left(20) if not firebase_display_name.is_empty() else "SIGNED IN"
    elif firebase_auth_status == "AUTH_ERROR":
        auth_button.text = "GOOGLE LOGIN"
        status_text = "LOGIN ERROR"
    else:
        auth_button.text = "GOOGLE LOGIN"
    if auth_status_label:
        auth_status_label.text = status_text
    if menu_auth_status_label:
        menu_auth_status_label.text = status_text

func _setup_firebase_service() -> void:
    firebase_service = preload("res://scripts/firebase_service.gd").new()
    add_child(firebase_service)
    firebase_service.leaderboard_loaded.connect(_on_firebase_leaderboard_loaded)
    firebase_service.leaderboard_failed.connect(_on_firebase_leaderboard_failed)
    firebase_service.auth_changed.connect(_on_firebase_auth_changed)
    firebase_service.auth_failed.connect(_on_firebase_auth_failed)
    firebase_service.score_saved.connect(_on_firebase_score_saved)
    firebase_service.score_failed.connect(_on_firebase_score_failed)
    firebase_service.rank_loaded.connect(_on_firebase_rank_loaded)
    firebase_service.rank_failed.connect(_on_firebase_rank_failed)
    online_leaderboard_status = "CONNECTING"
    firebase_service.continue_as_guest()
    firebase_service.load_public_leaderboard()

func _show_leaderboard() -> void:
    var box := _open_page("LEADERBOARD")
    if box == null:
        return
    leaderboard_label = _page_label(box, "", 24)
    _refresh_leaderboard()

func _refresh_leaderboard() -> void:
    if leaderboard_label == null:
        return

    var online := online_leaderboard_status == "ONLINE" and not leaderboard_entries.is_empty()
    var sorted_entries: Array = (leaderboard_entries if online else local_leaderboard).duplicate()
    sorted_entries.sort_custom(func(a, b) -> bool:
        return _leaderboard_time_value(a) < _leaderboard_time_value(b)
    )
    var text_lines := ["ONLINE TOP 10" if online else "LOCAL LEADERBOARD", ""]

    if sorted_entries.is_empty():
        text_lines.append("No records yet.")
    else:
        for i in range(mini(sorted_entries.size(), 10)):
            var entry = sorted_entries[i]
            text_lines.append("%02d. %s — %s" % [i + 1, str(entry.get("name", "PLAYER")), _format_race_time(_leaderboard_time_value(entry))])

    var rank := global_rank if global_rank > 0 else _get_own_rank(sorted_entries)
    if global_rank > 0:
        text_lines.append("")
        text_lines.append("GLOBAL RANK: #%d" % global_rank)
    elif rank > 0:
        text_lines.append("")
        text_lines.append("LOCAL TOP-100 RANK: #%d" % rank)
    elif firebase_auth_status == "SIGNED_IN":
        text_lines.append("")
        text_lines.append("YOUR RANK: Not ranked yet")

    if firebase_auth_status == "GUEST":
        text_lines.append("")
        text_lines.append("GUEST MODE • Online scores require Google Login")
    elif online:
        text_lines.append("")
        text_lines.append("FIREBASE • ONLINE")
    else:
        text_lines.append("")
        text_lines.append("OFFLINE • Showing local records")

    leaderboard_label.text = "\n".join(text_lines)

func _format_race_time(value: float) -> String:
    if value == INF:
        return "--"
    var minutes := int(value / 60.0)
    var seconds := fmod(value, 60.0)
    return "%02d:%05.2f" % [minutes, seconds]

func _get_own_rank(entries: Array) -> int:
    if firebase_auth_status != "SIGNED_IN" or firebase_service == null:
        return 0
    for i in range(entries.size()):
        var entry = entries[i]
        if str(entry.get("userId", "")) == str(firebase_service.user_id):
            return i + 1
    return 0

func _leaderboard_time_value(entry: Variant) -> float:
    if not (entry is Dictionary):
        return INF
    var raw_time = entry.get("time", INF)
    if raw_time is float or raw_time is int:
        return float(raw_time)

    var time_text := str(raw_time).strip_edges()
    if ":" in time_text:
        var parts := time_text.split(":")
        if parts.size() == 2:
            return float(parts[0]) * 60.0 + float(parts[1])
    return float(time_text) if time_text.is_valid_float() else INF

func _on_firebase_auth_changed(authenticated: bool, name: String) -> void:
    if authenticated:
        firebase_auth_status = "SIGNED_IN"
        firebase_display_name = name
        online_leaderboard_status = "CONNECTING"
        if firebase_service:
            firebase_service.load_public_leaderboard()
    else:
        firebase_auth_status = "GUEST"
        firebase_display_name = ""
    _update_auth_ui()

func _on_firebase_score_saved() -> void:
    online_leaderboard_status = "CONNECTING"
    if firebase_service:
        if firebase_service.last_submitted_time > 0.0:
            firebase_service.load_global_rank(firebase_service.last_submitted_time)
        firebase_service.load_public_leaderboard()
    if leaderboard_label and is_instance_valid(leaderboard_label):
        _refresh_leaderboard()

func _on_firebase_rank_loaded(rank: int) -> void:
    global_rank = rank
    if leaderboard_label and is_instance_valid(leaderboard_label):
        _refresh_leaderboard()

func _on_firebase_rank_failed(_message: String) -> void:
    global_rank = 0
    if leaderboard_label and is_instance_valid(leaderboard_label):
        _refresh_leaderboard()

func _on_firebase_score_failed(message: String) -> void:
    if firebase_auth_status == "SIGNED_IN":
        online_leaderboard_status = "OFFLINE"

func _on_firebase_auth_failed(message: String) -> void:
    firebase_auth_status = "AUTH_ERROR"
    _update_auth_ui()
    if auth_status_label:
        auth_status_label.text = message.left(24)

func _on_firebase_leaderboard_loaded(entries: Array) -> void:
    leaderboard_entries = entries
    online_leaderboard_status = "ONLINE"
    if leaderboard_label and is_instance_valid(leaderboard_label):
        _refresh_leaderboard()

func _on_firebase_leaderboard_failed(message: String) -> void:
    online_leaderboard_status = "OFFLINE"
    if leaderboard_label and is_instance_valid(leaderboard_label):
        _refresh_leaderboard()
        leaderboard_label.text += "\n\nFirebase: %s" % message

func _update_map_label() -> void:
    if map_label:
        map_label.text = "MAP: %s" % selected_map

func _update_rewards_hud() -> void:
    if coins_label:
        coins_label.text = "Coins: %d" % coins
    if reward_label:
        reward_label.text = "Rewards | XP: %d | Coins: %d" % [xp, coins]

func _rebuild_track_progress_cache() -> void:
    track_segment_lengths.clear()
    track_total_length = 0.0
    if track_path.size() < 2:
        return
    for i in range(track_path.size() - 1):
        var segment_length := track_path[i].distance_to(track_path[i + 1])
        track_segment_lengths.append(segment_length)
        track_total_length += segment_length

func _get_track_progress(position: Vector3, key: int = -1) -> float:
    if track_path.size() < 2 or track_total_length <= 0.0:
        return 0.0
    var use_hint := key >= 0
    var hint := float(progress_hints.get(key, 0.0)) if use_hint else 0.0
    var best_distance_sq := INF
    var best_progress := hint
    var accumulated := 0.0
    for i in range(track_path.size() - 1):
        var seg_len: float = track_segment_lengths[i]
        var start_frac := accumulated / track_total_length
        var end_frac := (accumulated + seg_len) / track_total_length
        if (not use_hint) or (end_frac >= hint - 0.05 and start_frac <= hint + 0.15):
            var a := track_path[i]
            var b := track_path[i + 1]
            var segment := b - a
            var length_sq := segment.length_squared()
            var t := 0.0
            if length_sq > 0.0001:
                t = clampf((position - a).dot(segment) / length_sq, 0.0, 1.0)
            var closest := a + segment * t
            var distance_sq := position.distance_squared_to(closest)
            if distance_sq < best_distance_sq:
                best_distance_sq = distance_sq
                best_progress = (accumulated + seg_len * t) / track_total_length
        accumulated += seg_len
    best_progress = clampf(best_progress, 0.0, 1.0)
    if use_hint:
        progress_hints[key] = best_progress
    return best_progress

func _update_ai_racing(_delta: float) -> void:
    ai_race_progress.clear()
    ai_last_positions.clear()

    var player := get_node_or_null("PlayerCar")
    var player_progress := 0.0
    if player:
        player_progress = _get_track_progress(player.global_position, 0)

    for ai in ai_opponents:
        if not is_instance_valid(ai):
            continue

        var progress := _get_track_progress(ai.global_position, ai.get_instance_id())
        ai_race_progress.append(progress)

        if progress >= 1.0 and ai.has_method("start_race"):
            ai.race_active = false
            ai.finished = true

        if player_progress > progress:
            ai_last_positions.append(1)
        else:
            ai_last_positions.append(0)

func _on_health_changed(current_health: float, maximum_health: float) -> void:
    if health_bar:
        health_bar.max_value = maximum_health
        health_bar.value = current_health
    if health_label:
        health_label.text = "Health %.0f%%" % (current_health / max(maximum_health, 0.0001) * 100.0)

func _on_game_over() -> void:
    if game_over_overlay:
        game_over_overlay.visible = true

func _build_ambience_audio() -> void:
    ambience_player = AudioStreamPlayer3D.new()
    ambience_player.name = "TrackAmbience"
    var stream := _create_ambience()
    ambience_player.stream = stream
    ambience_player.volume_db = -24.0
    ambience_player.max_distance = 80.0
    add_child(ambience_player)
    ambience_player.play()

func _create_ambience() -> AudioStreamWAV:
    var sample_rate := 22050
    var duration := 1.8
    var samples := int(sample_rate * duration)
    var data := PackedByteArray()
    data.resize(samples * 2)
    var rng := RandomNumberGenerator.new()
    rng.seed = 19427

    for i in samples:
        var t := float(i) / sample_rate
        var low := sin(TAU * 95.0 * t) * 0.06
        var mid := sin(TAU * 260.0 * t) * 0.025
        var noise := rng.randf_range(-1.0, 1.0) * 0.018
        data.encode_s16(i * 2, int(clamp(low + mid + noise, -1.0, 1.0) * 8000.0))

    var stream := AudioStreamWAV.new()
    stream.format = AudioStreamWAV.FORMAT_16_BITS
    stream.mix_rate = sample_rate
    stream.stereo = false
    stream.loop_mode = AudioStreamWAV.LOOP_FORWARD
    stream.loop_begin = 0
    stream.loop_end = samples
    stream.data = data
    return stream

func _build_music_system() -> void:
    music_player = AudioStreamPlayer.new()
    music_player.name = "RaceMusic"
    music_player.stream = _create_race_music()
    music_player.volume_db = -16.0
    music_player.bus = "Master"
    add_child(music_player)
    music_player.play()

func _create_race_music() -> AudioStreamWAV:
    var sample_rate := 22050
    var beat := 0.32
    var note_count := 32
    var samples_per_note := int(sample_rate * beat)
    var data := PackedByteArray()
    data.resize(samples_per_note * note_count * 2)
    var melody := [220.0, 261.63, 329.63, 392.0, 329.63, 261.63, 293.66, 349.23, 440.0, 349.23, 293.66, 261.63, 220.0, 293.66, 329.63, 392.0]
    for i in range(note_count):
        var frequency: float = melody[i % melody.size()]
        for sample in range(samples_per_note):
            var index := i * samples_per_note + sample
            var t := float(sample) / sample_rate
            var envelope := minf(1.0, t * 18.0) * minf(1.0, (beat - t) * 12.0)
            var tone := sin(TAU * frequency * t) * 0.11
            tone += sin(TAU * frequency * 2.0 * t) * 0.035
            tone += sin(TAU * frequency * 0.5 * t) * 0.025
            data.encode_s16(index * 2, int(clamp(tone * envelope, -1.0, 1.0) * 32767.0))
    var stream := AudioStreamWAV.new()
    stream.format = AudioStreamWAV.FORMAT_16_BITS
    stream.mix_rate = sample_rate
    stream.stereo = false
    stream.loop_mode = AudioStreamWAV.LOOP_FORWARD
    stream.loop_begin = 0
    stream.loop_end = samples_per_note * note_count
    stream.data = data
    return stream

func _build_environment() -> void:
    var world := WorldEnvironment.new()
    var environment := Environment.new()
    environment.background_mode = Environment.BG_SKY
    var sky := Sky.new()
    var sky_material := ProceduralSkyMaterial.new()
    sky_material.sky_top_color = Color(0.025, 0.07, 0.18)
    sky_material.sky_horizon_color = Color(0.62, 0.72, 0.82)
    sky_material.ground_bottom_color = Color(0.025, 0.035, 0.045)
    sky_material.ground_horizon_color = Color(0.24, 0.28, 0.3)
    sky_material.sun_angle_max = 12.0
    sky_material.sun_curve = 0.08
    sky.sky_material = sky_material
    environment.sky = sky
    environment.ambient_light_source = Environment.AMBIENT_SOURCE_SKY
    environment.ambient_light_energy = 0.72
    environment.reflected_light_source = Environment.REFLECTION_SOURCE_SKY
    environment.tonemap_mode = Environment.TONE_MAPPER_FILMIC
    environment.glow_enabled = false
    environment.glow_intensity = 0.7
    environment.glow_strength = 1.0
    environment.glow_bloom = 0.12
    environment.fog_enabled = true
    environment.fog_density = 0.003
    environment.fog_light_color = Color(0.55, 0.62, 0.7)
    world.environment = environment
    fog_environment = environment
    add_child(world)

    var sun := DirectionalLight3D.new()
    sun.name = "SunLight"
    sun.rotation_degrees = Vector3(-48.0, -32.0, 0.0)
    sun.light_color = Color(1.0, 0.92, 0.78)
    sun.light_energy = 1.45
    sun.shadow_enabled = true
    sun.directional_shadow_max_distance = 60.0
    sun.directional_shadow_fade_start = 55.0
    sun.directional_shadow_mode = DirectionalLight3D.SHADOW_PARALLEL_2_SPLITS
    add_child(sun)

    var fill := DirectionalLight3D.new()
    fill.name = "SkyFillLight"
    fill.rotation_degrees = Vector3(-25.0, 145.0, 0.0)
    fill.light_color = Color(0.55, 0.68, 1.0)
    fill.light_energy = 0.28
    fill.shadow_enabled = false
    add_child(fill)

    for position in [Vector3(-6.8, 3.0, 2.0), Vector3(12.0, 3.2, -26.0), Vector3(-7.5, 3.4, -48.0)]:
        var lamp := OmniLight3D.new()
        lamp.name = "TrackLight"
        lamp.position = position
        lamp.light_color = Color(1.0, 0.72, 0.38)
        lamp.light_energy = 1.8
        lamp.omni_range = 10.0
        lamp.shadow_enabled = false
        add_child(lamp)

func _apply_professional_lighting(weather: String) -> void:
    if not sun_light:
        sun_light = get_node_or_null("SunLight") as DirectionalLight3D
    if not sky_fill_light:
        sky_fill_light = get_node_or_null("SkyFillLight") as DirectionalLight3D
    if not sun_light:
        return
    if fog_environment and fog_environment.sky and fog_environment.sky.sky_material is ProceduralSkyMaterial:
        var sky_mat := fog_environment.sky.sky_material as ProceduralSkyMaterial
        if weather == "NIGHT":
            sky_mat.sky_top_color = Color(0.01, 0.015, 0.05)
            sky_mat.sky_horizon_color = Color(0.05, 0.07, 0.14)
            fog_environment.ambient_light_energy = 0.3
        elif weather == "RAIN":
            sky_mat.sky_top_color = Color(0.12, 0.15, 0.2)
            sky_mat.sky_horizon_color = Color(0.4, 0.45, 0.5)
            fog_environment.ambient_light_energy = 0.55
        else:
            sky_mat.sky_top_color = Color(0.025, 0.07, 0.18)
            sky_mat.sky_horizon_color = Color(0.62, 0.72, 0.82)
            fog_environment.ambient_light_energy = 0.72
    if weather == "NIGHT":
        sun_light.light_color = Color(0.34, 0.43, 0.68)
        sun_light.light_energy = 0.32 * lighting_tuning
        sun_light.rotation_degrees = Vector3(-18.0, 35.0, 0.0)
        if sky_fill_light:
            sky_fill_light.light_energy = 0.18
    elif weather == "RAIN":
        sun_light.light_color = Color(0.72, 0.78, 0.86)
        sun_light.light_energy = 0.82 * lighting_tuning
        sun_light.rotation_degrees = Vector3(-38.0, -28.0, 0.0)
        if sky_fill_light:
            sky_fill_light.light_energy = 0.24
    else:
        sun_light.light_color = Color(1.0, 0.92, 0.78)
        sun_light.light_energy = 1.45 * lighting_tuning
        sun_light.rotation_degrees = Vector3(-48.0, -32.0, 0.0)
        if sky_fill_light:
            sky_fill_light.light_energy = 0.28

func _build_professional_environment() -> void:
    var road_side := _make_material(Color(0.16, 0.19, 0.17), 0.0, 0.9)
    var rock := _make_material(Color(0.18, 0.2, 0.22), 0.0, 1.0)
    var tree_leaf := _make_material(Color(0.05, 0.2, 0.08), 0.0, 0.95)
    var tree_trunk := _make_material(Color(0.24, 0.12, 0.05), 0.0, 1.0)
    var sign_material := _make_emission_material(Color(0.95, 0.72, 0.12), 0.25)
    for i in range(9):
        var z := 12.0 - float(i) * 8.5
        _add_environment_tree(Vector3(-10.5 - float(i % 2), 0.0, z), tree_trunk, tree_leaf, 0.9 + float(i % 3) * 0.12)
        _add_environment_tree(Vector3(17.0 + float(i % 3), 0.0, z - 3.5), tree_trunk, tree_leaf, 1.0 + float((i + 1) % 3) * 0.1)
    for i in range(6):
        var z := 4.0 - float(i) * 10.5
        _add_roadside_sign(Vector3(-7.0, 1.5, z), 0.0, sign_material)
    for i in range(5):
        var z := -3.0 - float(i) * 12.0
        _add_rock(Vector3(-14.0 - float(i % 2) * 2.0, 1.2, z), rock, 1.0 + float(i % 3) * 0.35)
        _add_rock(Vector3(20.0 + float(i % 2) * 2.0, 1.0, z - 4.0), rock, 0.8 + float((i + 1) % 3) * 0.3)
    _add_environment_banner(Vector3(0.0, 4.8, 2.0), "RACE ZONE")

func _add_environment_tree(position: Vector3, trunk_material: StandardMaterial3D, leaf_material: StandardMaterial3D, scale_value: float) -> void:
    var root := Node3D.new()
    root.position = position
    root.scale = Vector3.ONE * scale_value
    add_child(root)
    var trunk := MeshInstance3D.new()
    var trunk_mesh := CylinderMesh.new()
    trunk_mesh.top_radius = 0.14
    trunk_mesh.bottom_radius = 0.25
    trunk_mesh.height = 2.8
    trunk.mesh = trunk_mesh
    trunk.position.y = 1.4
    trunk.material_override = trunk_material
    root.add_child(trunk)
    for offset in [Vector3(0.0, 2.9, 0.0), Vector3(0.0, 3.6, 0.2)]:
        var crown := MeshInstance3D.new()
        var crown_mesh := SphereMesh.new()
        crown_mesh.radius = 1.25
        crown_mesh.height = 2.4
        crown.mesh = crown_mesh
        crown.position = offset
        crown.material_override = leaf_material
        root.add_child(crown)

func _add_rock(position: Vector3, material: StandardMaterial3D, scale_value: float) -> void:
    var rock := MeshInstance3D.new()
    var mesh := SphereMesh.new()
    mesh.radius = 1.5
    mesh.height = 1.8
    rock.mesh = mesh
    rock.position = position
    rock.scale = Vector3(scale_value * 1.4, scale_value, scale_value)
    rock.rotation_degrees = Vector3(0.0, float(int(position.z * 7.0) % 35), 8.0)
    rock.material_override = material
    add_child(rock)

func _add_roadside_sign(position: Vector3, rotation_y: float, material: StandardMaterial3D) -> void:
    var root := Node3D.new()
    root.position = position
    root.rotation_degrees.y = rotation_y
    add_child(root)
    var pole := MeshInstance3D.new()
    var pole_mesh := CylinderMesh.new()
    pole_mesh.top_radius = 0.06
    pole_mesh.bottom_radius = 0.09
    pole_mesh.height = 2.6
    pole.mesh = pole_mesh
    pole.position.y = 1.3
    pole.material_override = _make_material(Color(0.12, 0.13, 0.14), 0.5, 0.45)
    root.add_child(pole)
    var board := MeshInstance3D.new()
    var board_mesh := BoxMesh.new()
    board_mesh.size = Vector3(1.8, 0.8, 0.1)
    board.mesh = board_mesh
    board.position.y = 2.7
    board.material_override = material
    root.add_child(board)

func _add_environment_banner(position: Vector3, text_value: String) -> void:
    var banner := MeshInstance3D.new()
    var mesh := BoxMesh.new()
    mesh.size = Vector3(9.0, 1.0, 0.25)
    banner.mesh = mesh
    banner.position = position
    banner.material_override = _make_emission_material(Color(0.06, 0.08, 0.12), 0.15)
    add_child(banner)

func _build_environment_scenery() -> void:
    var grass := _make_pbr_material(Color(0.07, 0.22, 0.09), 0.96, 0.0, 3.0, 301)
    var mountain := _make_pbr_material(Color(0.12, 0.16, 0.2), 0.92, 0.0, 2.0, 302)
    var building := _make_pbr_material(Color(0.22, 0.25, 0.3), 0.62, 0.22, 3.0, 303)
    var glass := _make_emission_material(Color(0.12, 0.28, 0.48), 0.45)
    var lamp := _make_pbr_material(Color(0.08, 0.09, 0.1), 0.3, 0.78, 2.0, 304)
    var sign := _make_emission_material(Color(0.95, 0.7, 0.12), 0.2)

    _add_ground(grass)
    _add_mountain_range(mountain)
    _add_tree_line(grass)
    _add_city_blocks(building, glass)
    _add_lamp_posts(lamp)
    _add_track_signs(sign)

func _add_ground(material: StandardMaterial3D) -> void:
    var ground := MeshInstance3D.new()
    var mesh := BoxMesh.new()
    mesh.size = Vector3(70.0, 0.5, 115.0)
    ground.mesh = mesh
    ground.position = Vector3(4.0, -0.45, -25.0)
    ground.material_override = material
    add_child(ground)

func _add_mountain_range(material: StandardMaterial3D) -> void:
    for i in range(8):
        var m := MeshInstance3D.new()
        var mesh := PrismMesh.new()
        mesh.size = Vector3(12.0, 10.0 + float(i % 3) * 3.0, 8.0)
        m.mesh = mesh
        m.position = Vector3(-28.0 + i * 8.0, 4.5, -72.0)
        m.rotation_degrees.y = float(i * 17)
        m.material_override = material
        add_child(m)

func _add_tree_line(material: StandardMaterial3D) -> void:
    for i in range(10):
        var z := 8.0 - i * 8.0
        _add_tree(Vector3(-11.0, 0.0, z), material, 0.9 + float(i % 3) * 0.12)
        if i > 2:
            _add_tree(Vector3(18.0, 0.2 + float(i) * 0.08, z - 4.0), material, 1.0 + float((i + 1) % 3) * 0.1)

func _add_tree(position: Vector3, material: StandardMaterial3D, scale_value: float) -> void:
    var tree := Node3D.new()
    tree.position = position
    tree.scale = Vector3.ONE * scale_value
    add_child(tree)

    var trunk := MeshInstance3D.new()
    var trunk_mesh := CylinderMesh.new()
    trunk_mesh.top_radius = 0.18
    trunk_mesh.bottom_radius = 0.3
    trunk_mesh.height = 2.4
    trunk.mesh = trunk_mesh
    trunk.position.y = 1.2
    trunk.material_override = _make_material(Color(0.25, 0.12, 0.05), 0.0, 1.0)
    tree.add_child(trunk)

    var crown := MeshInstance3D.new()
    var crown_mesh := SphereMesh.new()
    crown_mesh.radius = 1.45
    crown_mesh.height = 2.8
    crown.mesh = crown_mesh
    crown.position.y = 3.0
    crown.material_override = material
    tree.add_child(crown)

func _add_city_blocks(building_material: StandardMaterial3D, glass_material: StandardMaterial3D) -> void:
    var data := [
        [Vector3(-16.0, 2.5, -8.0), Vector3(6.0, 5.0, 6.0)],
        [Vector3(18.0, 3.5, -18.0), Vector3(7.0, 7.0, 7.0)],
        [Vector3(-18.0, 4.5, -36.0), Vector3(8.0, 9.0, 8.0)],
        [Vector3(20.0, 3.0, -47.0), Vector3(6.0, 6.0, 6.0)]
    ]
    for item in data:
        _add_building(item[0], item[1], building_material, glass_material)

func _add_building(position: Vector3, size: Vector3, building_material: StandardMaterial3D, glass_material: StandardMaterial3D) -> void:
    var building := MeshInstance3D.new()
    var mesh := BoxMesh.new()
    mesh.size = size
    building.mesh = mesh
    building.position = position
    building.material_override = building_material
    add_child(building)

    for y in range(1, maxi(2, int(size.y / 2.0))):
        var window := MeshInstance3D.new()
        var window_mesh := BoxMesh.new()
        window_mesh.size = Vector3(size.x * 0.6, 0.45, 0.06)
        window.mesh = window_mesh
        window.position = position + Vector3(0.0, -size.y * 0.5 + y * 1.5, size.z * 0.51)
        window.material_override = glass_material
        add_child(window)

func _add_lamp_posts(material: StandardMaterial3D) -> void:
    for i in range(7):
        var z := 6.0 - i * 9.0
        _add_lamp_post(Vector3(-8.0, 0.0, z), material, -1.0)
        if i % 2 == 0:
            _add_lamp_post(Vector3(15.0, 0.45 + float(i) * 0.06, z - 3.0), material, 1.0)

func _add_lamp_post(position: Vector3, material: StandardMaterial3D, side: float) -> void:
    var post := Node3D.new()
    post.position = position
    add_child(post)

    var pole := MeshInstance3D.new()
    var pole_mesh := CylinderMesh.new()
    pole_mesh.top_radius = 0.08
    pole_mesh.bottom_radius = 0.12
    pole_mesh.height = 4.0
    pole.mesh = pole_mesh
    pole.position.y = 2.0
    pole.material_override = material
    post.add_child(pole)

    var arm := MeshInstance3D.new()
    var arm_mesh := BoxMesh.new()
    arm_mesh.size = Vector3(1.1, 0.12, 0.12)
    arm.mesh = arm_mesh
    arm.position = Vector3(side * 0.45, 4.0, 0.0)
    arm.material_override = material
    post.add_child(arm)

    var light := OmniLight3D.new()
    light.position = Vector3(side * 0.85, 3.85, 0.0)
    light.omni_range = 8.0
    light.light_energy = 1.0
    light.light_color = Color(1.0, 0.82, 0.55)
    post.add_child(light)

    var bulb := MeshInstance3D.new()
    var bulb_mesh := SphereMesh.new()
    bulb_mesh.radius = 0.16
    bulb_mesh.height = 0.32
    bulb.mesh = bulb_mesh
    bulb.position = light.position
    bulb.material_override = _make_emission_material(Color(1.0, 0.75, 0.35), 2.0)
    post.add_child(bulb)

func _add_track_signs(_material: StandardMaterial3D = null) -> void:
    _add_sign(Vector3(-7.2, 1.2, -12.0), 8.0, "CURVE")
    _add_sign(Vector3(15.0, 1.3, -34.0), -18.0, "RAMP")
    _add_sign(Vector3(14.5, 1.3, -57.0), -10.0, "FINISH")

func _add_sign(position: Vector3, rotation_y: float, text_value: String) -> void:
    var sign_root := Node3D.new()
    sign_root.position = position
    sign_root.rotation_degrees.y = rotation_y
    add_child(sign_root)

    var pole := MeshInstance3D.new()
    var pole_mesh := CylinderMesh.new()
    pole_mesh.top_radius = 0.06
    pole_mesh.bottom_radius = 0.09
    pole_mesh.height = 2.2
    pole.mesh = pole_mesh
    pole.position.y = 1.1
    pole.material_override = _make_material(Color(0.16, 0.17, 0.19), 0.55, 0.5)
    sign_root.add_child(pole)

    var material := _make_material(Color(0.05, 0.22, 0.5), 0.2, 0.5)
    var board := MeshInstance3D.new()
    var board_mesh := BoxMesh.new()
    board_mesh.size = Vector3(2.8, 1.0, 0.12)
    board.mesh = board_mesh
    board.position.y = 2.35
    board.material_override = material
    sign_root.add_child(board)

func _build_premium_environment() -> void:
    var grass := _make_material(Color(0.055, 0.16, 0.065), 0.0, 0.98)
    var dark_grass := _make_material(Color(0.035, 0.095, 0.045), 0.0, 1.0)
    var glass := _make_emission_material(Color(0.08, 0.22, 0.42), 0.7)
    var concrete := _make_material(Color(0.2, 0.21, 0.23), 0.15, 0.78)
    var road_sign := _make_emission_material(Color(0.95, 0.62, 0.08), 0.35)

    for i in range(12):
        var z := 10.0 - float(i) * 6.5
        _add_premium_tree_cluster(Vector3(-12.0 - float(i % 3) * 1.5, 0.0, z), grass, dark_grass, 1.0 + float(i % 3) * 0.12)
        _add_premium_tree_cluster(Vector3(17.0 + float(i % 2) * 2.0, 0.0, z - 2.5), grass, dark_grass, 0.9 + float((i + 1) % 3) * 0.15)

    var buildings := [
        [Vector3(-17.0, 4.0, -4.0), Vector3(5.5, 8.0, 5.5)],
        [Vector3(18.0, 5.5, -15.0), Vector3(6.5, 11.0, 6.5)],
        [Vector3(-18.0, 6.0, -29.0), Vector3(7.0, 12.0, 7.0)],
        [Vector3(20.0, 4.5, -43.0), Vector3(6.0, 9.0, 6.0)],
        [Vector3(-16.0, 5.0, -55.0), Vector3(6.0, 10.0, 6.0)]
    ]
    for item in buildings:
        _add_premium_building(item[0], item[1], concrete, glass)

    _add_premium_bridge(Vector3(3.5, 4.5, -21.0), 18.0, concrete)
    _add_premium_sign(Vector3(-7.5, 2.0, -18.0), "RACE", road_sign)
    _add_premium_sign(Vector3(14.0, 2.0, -38.0), "SLOW", road_sign)

func _add_premium_tree_cluster(position: Vector3, leaf_material: StandardMaterial3D, dark_material: StandardMaterial3D, scale_value: float) -> void:
    var root := Node3D.new()
    root.position = position
    root.scale = Vector3.ONE * scale_value
    add_child(root)

    var trunk := MeshInstance3D.new()
    var trunk_mesh := CylinderMesh.new()
    trunk_mesh.top_radius = 0.16
    trunk_mesh.bottom_radius = 0.28
    trunk_mesh.height = 3.2
    trunk.mesh = trunk_mesh
    trunk.position.y = 1.6
    trunk.material_override = _make_material(Color(0.2, 0.09, 0.035), 0.0, 1.0)
    root.add_child(trunk)

    for offset in [Vector3(0.0, 3.1, 0.0), Vector3(-0.65, 2.8, 0.15), Vector3(0.65, 2.8, -0.1)]:
        var crown := MeshInstance3D.new()
        var crown_mesh := SphereMesh.new()
        crown_mesh.radius = 1.25
        crown_mesh.height = 2.4
        crown.mesh = crown_mesh
        crown.position = offset
        crown.material_override = leaf_material if offset.x == 0.0 else dark_material
        root.add_child(crown)

func _add_premium_building(position: Vector3, size: Vector3, concrete: StandardMaterial3D, glass: StandardMaterial3D) -> void:
    var root := Node3D.new()
    root.position = position
    add_child(root)

    var body := MeshInstance3D.new()
    var body_mesh := BoxMesh.new()
    body_mesh.size = size
    body.mesh = body_mesh
    body.material_override = concrete
    root.add_child(body)

    for y in range(1, max(2, int(size.y / 2.0))):
        for side in [-1.0, 1.0]:
            var window := MeshInstance3D.new()
            var window_mesh := BoxMesh.new()
            window_mesh.size = Vector3(size.x * 0.62, 0.5, 0.08)
            window.mesh = window_mesh
            window.position = Vector3(0.0, -size.y * 0.5 + y * 1.55, side * size.z * 0.505)
            window.material_override = glass
            root.add_child(window)

func _add_premium_bridge(position: Vector3, rotation_y: float, material: StandardMaterial3D) -> void:
    var bridge := Node3D.new()
    bridge.position = position
    bridge.rotation_degrees.y = rotation_y
    add_child(bridge)

    var deck := MeshInstance3D.new()
    var deck_mesh := BoxMesh.new()
    deck_mesh.size = Vector3(16.0, 0.45, 3.2)
    deck.mesh = deck_mesh
    deck.position.y = 4.0
    deck.material_override = material
    bridge.add_child(deck)

    for side in [-1.0, 1.0]:
        for x in [-6.0, 0.0, 6.0]:
            var pillar := MeshInstance3D.new()
            var pillar_mesh := BoxMesh.new()
            pillar_mesh.size = Vector3(0.45, 4.0, 0.45)
            pillar.mesh = pillar_mesh
            pillar.position = Vector3(x, 2.0, side * 1.1)
            pillar.material_override = material
            bridge.add_child(pillar)

func _add_premium_sign(position: Vector3, text_value: String, material: StandardMaterial3D) -> void:
    var sign := Node3D.new()
    sign.position = position
    add_child(sign)

    var pole := MeshInstance3D.new()
    var pole_mesh := CylinderMesh.new()
    pole_mesh.top_radius = 0.07
    pole_mesh.bottom_radius = 0.1
    pole_mesh.height = 3.2
    pole.mesh = pole_mesh
    pole.position.y = 1.6
    pole.material_override = _make_material(Color(0.12, 0.13, 0.15), 0.65, 0.4)
    sign.add_child(pole)

    var board := MeshInstance3D.new()
    var board_mesh := BoxMesh.new()
    board_mesh.size = Vector3(2.6, 0.85, 0.14)
    board.mesh = board_mesh
    board.position.y = 3.15
    board.material_override = material
    sign.add_child(board)

func _make_pbr_material(base_color: Color, roughness_value: float, metallic_value: float, texture_scale: float = 4.0, seed_value: int = 1) -> StandardMaterial3D:
    var material := StandardMaterial3D.new()
    material.albedo_color = base_color
    material.metallic = clampf(metallic_value, 0.0, 1.0)
    material.roughness = clampf(roughness_value, 0.05, 1.0)
    material.texture_filter = BaseMaterial3D.TEXTURE_FILTER_LINEAR_WITH_MIPMAPS_ANISOTROPIC
    material.uv1_triplanar = true
    material.uv1_world_triplanar = true
    material.uv1_scale = Vector3.ONE * texture_scale
    var image := Image.create(32, 32, false, Image.FORMAT_RGBA8)
    var rng := RandomNumberGenerator.new()
    rng.seed = seed_value
    for y in range(32):
        for x in range(32):
            var variation := rng.randf_range(0.82, 1.18)
            image.set_pixel(x, y, Color(base_color.r * variation, base_color.g * variation, base_color.b * variation, 1.0))
    material.albedo_texture = ImageTexture.create_from_image(image)
    return material

func _make_material(color: Color, metallic: float, roughness: float) -> StandardMaterial3D:
    var material := _make_pbr_material(color, roughness, metallic, 2.5, 401)
    return material

func _make_emission_material(color: Color, energy: float) -> StandardMaterial3D:
    var material := _make_material(color, 0.1, 0.12)
    material.emission_enabled = true
    material.emission = color
    material.emission_energy_multiplier = energy
    return material

func _build_high_quality_environment() -> void:
    var terrain := _make_pbr_material(Color(0.035, 0.11, 0.045), 0.98, 0.0, 3.0, 101)
    var terrain_edge := _make_material(Color(0.07, 0.18, 0.08), 0.0, 0.92)
    var foliage := _make_pbr_material(Color(0.025, 0.14, 0.055), 0.95, 0.0, 2.0, 103)
    var foliage_light := _make_pbr_material(Color(0.08, 0.28, 0.11), 0.9, 0.0, 2.0, 104)
    var concrete := _make_pbr_material(Color(0.16, 0.18, 0.2), 0.72, 0.18, 3.0, 105)
    var glass := _make_emission_material(Color(0.08, 0.3, 0.58), 0.9)
    var metal := _make_pbr_material(Color(0.22, 0.24, 0.27), 0.32, 0.82, 2.0, 106)
    var accent := _make_emission_material(Color(0.95, 0.18, 0.035), 0.65)

    _add_environment_terrain_layer(Vector3(4.0, -0.18, -27.0), Vector3(92.0, 0.28, 122.0), terrain)
    _add_environment_terrain_layer(Vector3(4.0, 0.02, -27.0), Vector3(78.0, 0.12, 112.0), terrain_edge)

    for i in range(18):
        var z := 13.0 - float(i) * 5.1
        var side := -1.0 if i % 2 == 0 else 1.0
        _add_high_quality_tree(Vector3(-11.5 + side * 0.8, 0.0, z), foliage, foliage_light, 1.0 + float(i % 4) * 0.08)
        _add_high_quality_tree(Vector3(16.0 - side * 0.7, 0.0, z - 2.2), foliage, foliage_light, 0.9 + float((i + 1) % 4) * 0.09)

    for i in range(8):
        var z := 8.0 - float(i) * 9.0
        _add_roadside_barrier(Vector3(-7.1, 0.35, z), 0.0, metal)
        if i % 2 == 0:
            _add_roadside_barrier(Vector3(13.0, 0.55, z - 3.0), 0.0, metal)

    var skyline := [
        [Vector3(-22.0, 5.0, -8.0), Vector3(6.0, 10.0, 6.0)],
        [Vector3(23.0, 7.0, -22.0), Vector3(7.0, 14.0, 7.0)],
        [Vector3(-23.0, 8.0, -39.0), Vector3(8.0, 16.0, 8.0)],
        [Vector3(24.0, 6.0, -57.0), Vector3(7.0, 12.0, 7.0)]
    ]
    for item in skyline:
        _add_high_quality_building(item[0], item[1], concrete, glass)

    _add_environment_banner(Vector3(0.0, 5.0, -9.0), "NOVA RACING")
    _add_environment_banner(Vector3(7.0, 5.4, -49.0), "SPEED ZONE")

    for position in [Vector3(-9.0, 0.0, 9.0), Vector3(12.0, 0.1, -6.0), Vector3(-10.0, 0.1, -31.0), Vector3(14.0, 0.2, -52.0)]:
        _add_rock_cluster(position, terrain_edge)

    var accent_positions := [Vector3(-6.5, 1.1, 1.0), Vector3(11.5, 1.3, -27.0), Vector3(-9.0, 1.5, -45.0)]
    for position in accent_positions:
        _add_premium_sign(position + Vector3(0.0, 2.8, 0.0), "RACE", accent)

func _add_environment_terrain_layer(position: Vector3, size: Vector3, material: StandardMaterial3D) -> void:
    var mesh_instance := MeshInstance3D.new()
    var mesh := BoxMesh.new()
    mesh.size = size
    mesh_instance.mesh = mesh
    mesh_instance.position = position
    mesh_instance.material_override = material
    add_child(mesh_instance)

func _add_high_quality_tree(position: Vector3, leaf_material: StandardMaterial3D, light_material: StandardMaterial3D, scale_value: float) -> void:
    var root := Node3D.new()
    root.position = position
    root.scale = Vector3.ONE * scale_value
    add_child(root)

    var trunk := MeshInstance3D.new()
    var trunk_mesh := CylinderMesh.new()
    trunk_mesh.top_radius = 0.11
    trunk_mesh.bottom_radius = 0.22
    trunk_mesh.height = 3.4
    trunk.mesh = trunk_mesh
    trunk.position.y = 1.7
    trunk.material_override = _make_material(Color(0.16, 0.07, 0.025), 0.0, 1.0)
    root.add_child(trunk)

    for data in [
        [Vector3(0.0, 3.15, 0.0), 1.25, 2.4],
        [Vector3(-0.75, 2.65, 0.15), 0.95, 1.9],
        [Vector3(0.72, 2.55, -0.12), 0.9, 1.8]
    ]:
        var crown := MeshInstance3D.new()
        var crown_mesh := SphereMesh.new()
        crown_mesh.radius = data[1]
        crown_mesh.height = data[2]
        crown.mesh = crown_mesh
        crown.position = data[0]
        crown.material_override = light_material if data[0].x != 0.0 else leaf_material
        root.add_child(crown)

func _add_roadside_barrier(position: Vector3, rotation_y: float, material: StandardMaterial3D) -> void:
    var root := Node3D.new()
    root.position = position
    root.rotation_degrees.y = rotation_y
    add_child(root)

    for x in [-1.8, 0.0, 1.8]:
        var post := MeshInstance3D.new()
        var post_mesh := CylinderMesh.new()
        post_mesh.top_radius = 0.06
        post_mesh.bottom_radius = 0.08
        post_mesh.height = 0.8
        post.mesh = post_mesh
        post.position = Vector3(x, 0.4, 0.0)
        post.material_override = material
        root.add_child(post)

    var rail := MeshInstance3D.new()
    var rail_mesh := BoxMesh.new()
    rail_mesh.size = Vector3(4.0, 0.16, 0.16)
    rail.mesh = rail_mesh
    rail.position.y = 0.65
    rail.material_override = material
    root.add_child(rail)

func _add_high_quality_building(position: Vector3, size: Vector3, body_material: StandardMaterial3D, glass_material: StandardMaterial3D) -> void:
    var root := Node3D.new()
    root.position = position
    add_child(root)

    var body := MeshInstance3D.new()
    var body_mesh := BoxMesh.new()
    body_mesh.size = size
    body.mesh = body_mesh
    body.material_override = body_material
    root.add_child(body)

    var roof := MeshInstance3D.new()
    var roof_mesh := BoxMesh.new()
    roof_mesh.size = Vector3(size.x * 1.08, 0.28, size.z * 1.08)
    roof.mesh = roof_mesh
    roof.position.y = size.y * 0.5 + 0.14
    roof.material_override = _make_material(Color(0.06, 0.07, 0.09), 0.45, 0.42)
    root.add_child(roof)

    var floors: int = max(3, int(size.y / 1.8))
    for y in range(floors):
        for side in [-1.0, 1.0]:
            var window := MeshInstance3D.new()
            var window_mesh := BoxMesh.new()
            window_mesh.size = Vector3(size.x * 0.7, 0.48, 0.07)
            window.mesh = window_mesh
            window.position = Vector3(0.0, -size.y * 0.5 + 1.15 + y * 1.65, side * size.z * 0.505)
            window.material_override = glass_material
            root.add_child(window)

func _add_rock_cluster(position: Vector3, material: StandardMaterial3D) -> void:
    for i in range(3):
        var rock := MeshInstance3D.new()
        var mesh := SphereMesh.new()
        mesh.radius = 0.6 + float(i) * 0.18
        mesh.height = 0.8 + float(i) * 0.2
        rock.mesh = mesh
        rock.position = position + Vector3(float(i) * 0.55, 0.35 + float(i % 2) * 0.12, float(i % 2) * 0.5)
        rock.scale = Vector3(1.2, 0.8, 1.0)
        rock.material_override = material
        add_child(rock)

func _build_professional_track() -> void:
    track_path = _get_map_track_path()
    for i in range(track_path.size() - 1):
        _add_curved_road_segment(track_path[i], track_path[i + 1], i)
    if track_path.size() > 17:
        _add_curve_apex_marker(track_path[5])
        _add_curve_apex_marker(track_path[11])
        _add_curve_apex_marker(track_path[17])

func _get_map_track_path() -> Array[Vector3]:
    if selected_map == "HIGHWAY":
        return [
            Vector3(0.0, 0.0, 18.0), Vector3(0.0, 0.0, 10.0), Vector3(1.0, 0.0, 2.0),
            Vector3(3.5, 0.02, -6.0), Vector3(7.0, 0.04, -14.0), Vector3(8.5, 0.08, -22.0),
            Vector3(7.0, 0.12, -30.0), Vector3(2.5, 0.16, -38.0), Vector3(-3.5, 0.2, -46.0),
            Vector3(-7.5, 0.24, -54.0), Vector3(-6.5, 0.28, -62.0), Vector3(-1.5, 0.32, -70.0),
            Vector3(5.0, 0.36, -78.0), Vector3(10.0, 0.4, -86.0), Vector3(12.0, 0.44, -94.0),
            Vector3(9.0, 0.48, -102.0), Vector3(3.0, 0.52, -108.0), Vector3(-4.0, 0.56, -112.0),
            Vector3(-10.0, 0.6, -108.0), Vector3(-12.0, 0.64, -100.0), Vector3(-9.0, 0.68, -92.0),
            Vector3(-3.0, 0.72, -84.0), Vector3(3.0, 0.76, -76.0)
        ]
    if selected_map == "DESERT":
        return [
            Vector3(0.0, 0.0, 16.0), Vector3(-4.0, 0.02, 9.0), Vector3(-8.0, 0.04, 2.0),
            Vector3(-9.0, 0.06, -6.0), Vector3(-5.0, 0.1, -14.0), Vector3(2.0, 0.14, -20.0),
            Vector3(9.0, 0.18, -25.0), Vector3(12.0, 0.22, -32.0), Vector3(10.0, 0.26, -40.0),
            Vector3(4.0, 0.3, -47.0), Vector3(-4.0, 0.34, -52.0), Vector3(-12.0, 0.38, -56.0),
            Vector3(-16.0, 0.42, -63.0), Vector3(-13.0, 0.46, -70.0), Vector3(-5.0, 0.5, -75.0),
            Vector3(4.0, 0.54, -77.0), Vector3(13.0, 0.58, -74.0), Vector3(17.0, 0.62, -67.0),
            Vector3(15.0, 0.66, -59.0), Vector3(8.0, 0.7, -54.0), Vector3(0.0, 0.74, -50.0),
            Vector3(-7.0, 0.78, -45.0), Vector3(-11.0, 0.82, -38.0)
        ]
    return [
        Vector3(0.0, 0.0, 15.0), Vector3(-0.8, 0.0, 11.0), Vector3(-2.2, 0.0, 7.0),
        Vector3(-3.8, 0.02, 3.0), Vector3(-4.8, 0.04, -1.0), Vector3(-4.5, 0.06, -5.0),
        Vector3(-2.8, 0.08, -9.0), Vector3(0.0, 0.1, -13.0), Vector3(3.5, 0.14, -17.0),
        Vector3(6.5, 0.18, -21.0), Vector3(8.2, 0.22, -25.0), Vector3(8.8, 0.28, -29.0),
        Vector3(8.0, 0.34, -33.0), Vector3(5.5, 0.4, -37.0), Vector3(2.0, 0.48, -40.0),
        Vector3(-1.5, 0.56, -43.0), Vector3(-3.8, 0.62, -47.0), Vector3(-4.5, 0.68, -51.0),
        Vector3(-3.2, 0.74, -55.0), Vector3(0.0, 0.8, -59.0), Vector3(4.0, 0.86, -63.0),
        Vector3(7.2, 0.92, -67.0), Vector3(8.5, 0.98, -71.0)
    ]

func _add_curved_road_segment(a: Vector3, b: Vector3, index: int) -> void:
    var midpoint := (a + b) * 0.5
    var direction := b - a
    var length := maxf(direction.length() + 0.35, 1.0)
    var angle := atan2(direction.x, direction.z)
    var road := StaticBody3D.new()
    road.name = "CurvedRoad%02d" % index
    road.position = midpoint
    road.rotation.y = angle
    add_child(road)

    var road_mesh := MeshInstance3D.new()
    var road_box := BoxMesh.new()
    road_box.size = Vector3(12.0, 0.24, length)
    road_mesh.mesh = road_box
    road_mesh.position.y = -0.08
    road_mesh.material_override = _make_pbr_material(Color(0.055, 0.06, 0.075), 0.84, 0.05, 5.0, 200 + index)
    road.add_child(road_mesh)

    var collision := CollisionShape3D.new()
    var collision_shape := BoxShape3D.new()
    collision_shape.size = Vector3(12.0, 0.24, length)
    collision.shape = collision_shape
    collision.position.y = -0.08
    road.add_child(collision)

    for side in [-1.0, 1.0]:
        var curb := MeshInstance3D.new()
        var curb_mesh := BoxMesh.new()
        curb_mesh.size = Vector3(0.32, 0.14, length)
        curb.mesh = curb_mesh
        curb.position = Vector3(side * 6.16, 0.08, 0.0)
        curb.material_override = _make_material(Color(0.72, 0.73, 0.75), 0.1, 0.68)
        road.add_child(curb)

        var red_curb := MeshInstance3D.new()
        var red_mesh := BoxMesh.new()
        red_mesh.size = Vector3(0.32, 0.15, minf(length * 0.5, 2.0))
        red_curb.mesh = red_mesh
        red_curb.position = Vector3(side * 6.16, 0.09, -length * 0.24)
        red_curb.material_override = _make_material(Color(0.72, 0.035, 0.025), 0.05, 0.7)
        road.add_child(red_curb)

    var dash := MeshInstance3D.new()
    var dash_mesh := BoxMesh.new()
    dash_mesh.size = Vector3(0.16, 0.035, minf(length * 0.55, 1.8))
    dash.mesh = dash_mesh
    dash.position.y = 0.065
    dash.material_override = _make_emission_material(Color(0.95, 0.92, 0.72), 0.2)
    road.add_child(dash)

    if index % 2 == 0:
        var edge := MeshInstance3D.new()
        var edge_mesh := BoxMesh.new()
        edge_mesh.size = Vector3(0.08, 0.05, length)
        edge.mesh = edge_mesh
        edge.position = Vector3(-5.72, 0.09, 0.0)
        edge.material_override = _make_emission_material(Color(0.95, 0.8, 0.18), 0.18)
        road.add_child(edge)

func _add_curve_apex_marker(position: Vector3) -> void:
    var marker := MeshInstance3D.new()
    var mesh := CylinderMesh.new()
    mesh.top_radius = 0.16
    mesh.bottom_radius = 0.16
    mesh.height = 0.8
    marker.name = "ApexMarker"
    marker.mesh = mesh
    marker.position = position + Vector3(0.0, 0.45, 0.0)
    marker.material_override = _make_emission_material(Color(1.0, 0.28, 0.05), 0.7)
    add_child(marker)

func _show_car_selector() -> void:
    var box := _open_page("GARAGE / CARS")
    if box == null:
        return
    _build_car_select(box)

func _build_car_select(parent: Control) -> void:
    car_label = _page_label(parent, "", 22)
    car_label.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER

    var car_grid := _page_grid(parent, 3)
    for item in ["SPORTS", "MUSCLE", "GT", "SUPERCAR", "HYPER", "RALLY"]:
        var car_name: String = item
        _add_car_button(car_grid, car_name)

    customization_label = _page_label(parent, "", 20)
    customization_label.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER

    var custom_grid := _page_grid(parent, 3)
    _add_custom_button(custom_grid, "RED", "color_red")
    _add_custom_button(custom_grid, "BLUE", "color_blue")
    _add_custom_button(custom_grid, "GREEN", "color_green")
    _add_custom_button(custom_grid, "SPORT WHEELS", "wheel_sport")
    _add_custom_button(custom_grid, "BLACK WHEELS", "wheel_black")
    _add_custom_button(custom_grid, "GOLD WHEELS", "wheel_gold")
    _page_button(parent, "UPGRADE +", func() -> void: _apply_customization("upgrade"))

    _update_car_selection_label()

func _add_car_button(parent: Control, car_name: String) -> void:
    _page_button(parent, car_name, func() -> void:
        selected_car = car_name
        _apply_selected_car_to_player()
        _update_car_selection_label()
        _save_progress()
    )

func _add_custom_button(parent: Control, label_name: String, action_name: String) -> void:
    _page_button(parent, label_name, func() -> void:
        _apply_customization(action_name)
    )

func _apply_customization(action_name: String) -> void:
    match action_name:
        "color_red":
            selected_color = Color(0.82, 0.025, 0.02)
        "color_blue":
            selected_color = Color(0.04, 0.22, 0.88)
        "color_green":
            selected_color = Color(0.05, 0.7, 0.18)
        "wheel_sport":
            selected_wheels = "SPORT"
        "wheel_black":
            selected_wheels = "BLACK"
        "wheel_gold":
            selected_wheels = "GOLD"
        "upgrade":
            if upgrade_level < 3:
                upgrade_level += 1
        _:
            return
    _apply_selected_car_to_player()
    _update_car_selection_label()
    _save_progress()

func _apply_selected_car_to_player() -> void:
    var car := get_node_or_null("PlayerCar")
    if car == null:
        return
    if car.has_method("configure_car"):
        car.configure_car(selected_car)
    if car.has_method("customize_car"):
        car.customize_car(selected_color, selected_wheels, upgrade_level)

func _update_car_selection_label() -> void:
    var stats := {
        "SPORTS": [34, 18, 2.2],
        "MUSCLE": [31, 20, 1.9],
        "GT": [36, 17, 2.4],
        "SUPERCAR": [42, 23, 2.8],
        "HYPER": [48, 26, 3.0],
        "RALLY": [33, 21, 2.5]
    }
    var values: Array = stats.get(selected_car, [34, 18, 2.2])
    var speed_value := float(values[0]) + upgrade_level * 2.0
    var acceleration_value := float(values[1]) + upgrade_level * 1.5
    var handling_value := float(values[2]) + upgrade_level * 0.1
    if car_label:
        car_label.text = "CAR: %s\nSpeed %.0f | Acceleration %.1f | Handling %.1f" % [selected_car, speed_value, acceleration_value, handling_value]
    if customization_label:
        customization_label.text = "COLOR: %s   WHEELS: %s   UPGRADE: %d/3" % [_get_color_name(), selected_wheels, upgrade_level]

func _get_color_name() -> String:
    var hex := selected_color.to_html(false)
    if hex == Color(0.04, 0.22, 0.88).to_html(false):
        return "BLUE"
    if hex == Color(0.05, 0.7, 0.18).to_html(false):
        return "GREEN"
    return "RED"


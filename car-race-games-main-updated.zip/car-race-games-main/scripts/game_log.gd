extends Node
# GameLog autoload: collects everything, saves to a file,
# and shows a log panel when Back is pressed twice quickly.

const FILE_CUR := "user://game_log.txt"
const FILE_PREV := "user://game_log_prev.txt"
const MAX_LINES := 4000
const SHOW_LINES := 800
const MAX_FILE_BYTES := 1500000
const DOUBLE_WINDOW_MS := 800
const DEDUPE_MS := 120
const HEARTBEAT_SEC := 10.0
const COPY_MAX_CHARS := 300000

var plain: Array[String] = []
var levels: Array[int] = []
var capture: Object = null
var file: FileAccess = null
var file_bytes: int = 0

var layer: CanvasLayer
var panel: Control
var scroll: ScrollContainer
var rtl: RichTextLabel
var status_label: Label
var btn_filter: Button
var btn_prev: Button

var errors_only: bool = false
var show_prev: bool = false
var prev_plain: Array[String] = []
var prev_levels: Array[int] = []
var dirty: bool = false
var refresh_cd: float = 0.0
var heartbeat_cd: float = HEARTBEAT_SEC

var _last_evt: int = -100000
var _first_back: int = -100000


func _ready() -> void:
	process_mode = Node.PROCESS_MODE_ALWAYS
	get_tree().set_quit_on_go_back(false)
	_rotate_files()
	_open_file()
	_setup_capture()
	_add(0, "=== SESSION START ===")
	_log_device_info()
	_health_check()


func _rotate_files() -> void:
	if FileAccess.file_exists(FILE_CUR):
		var f := FileAccess.open(FILE_CUR, FileAccess.READ)
		if f != null:
			var content := f.get_as_text()
			f.close()
			var w := FileAccess.open(FILE_PREV, FileAccess.WRITE)
			if w != null:
				w.store_string(content)
				w.close()


func _open_file() -> void:
	file = FileAccess.open(FILE_CUR, FileAccess.WRITE)
	file_bytes = 0


func _setup_capture() -> void:
	if not ClassDB.class_exists("Logger"):
		_add(1, "Engine Logger class not available - only GameLog messages are captured")
		return
	var scr: Resource = load("res://scripts/engine_log_capture.gd")
	if scr == null or not (scr is GDScript) or not (scr as GDScript).can_instantiate():
		_add(1, "engine_log_capture.gd failed to load - engine errors are not captured")
		return
	capture = (scr as GDScript).new()
	OS.add_logger(capture)


func _log_device_info() -> void:
	_add(0, "Godot " + str(Engine.get_version_info().get("string", "?")))
	_add(0, "OS: %s %s | model: %s" % [OS.get_name(), OS.get_version(), OS.get_model_name()])
	_add(0, "GPU: " + RenderingServer.get_video_adapter_name())
	_add(0, "Window: " + str(DisplayServer.window_get_size()) + " | screen: " + str(DisplayServer.screen_get_size()))
	_add(0, "Android build: " + str(OS.has_feature("android")))
	_add(0, "FirebaseGoogleSignIn plugin: " + str(Engine.has_singleton("FirebaseGoogleSignIn")))


func _health_check() -> void:
	for path in ["res://scripts/ai_car.gd", "res://scripts/player_car.gd", "res://scripts/firebase_service.gd", "res://scripts/google_signin.gd", "res://scripts/main.gd"]:
		if not ResourceLoader.exists(path):
			_add(2, "MISSING: " + path)
			continue
		var res: Resource = load(path)
		if res == null:
			_add(2, "FAIL load: " + path)
		elif res is GDScript:
			var ok: bool = (res as GDScript).can_instantiate()
			_add(0 if ok else 2, ("OK   " if ok else "FAIL ") + path.get_file() + " can_instantiate=" + str(ok))
	await get_tree().create_timer(2.5).timeout
	var cs: Node = get_tree().current_scene
	if cs == null:
		_add(2, "No current scene after 2.5s")
		return
	_add(0, "Scene: %s | children=%d" % [cs.name, cs.get_child_count()])
	var tp: Variant = cs.get("track_path")
	_add(0, "track_path size=" + (str(tp.size()) if tp != null else "null"))
	var cam: Camera3D = get_viewport().get_camera_3d()
	_add(0 if cam != null else 1, "camera=" + (str(cam.global_position) if cam != null else "NONE"))


# ---------- public API (use from any script: GameLog.info("...")) ----------
func info(msg: String) -> void:
	_add(0, msg)


func warn(msg: String) -> void:
	_add(1, msg)


func error(msg: String) -> void:
	_add(2, msg)


# ---------- core ----------
func _add(level: int, text: String, from_engine: bool = false) -> void:
	var tag := "E" if level == 2 else ("W" if level == 1 else "I")
	var stamp := "[%8.3f]" % (Time.get_ticks_msec() / 1000.0)
	for part in text.split("\n"):
		var one := String(part).rstrip("\r")
		plain.append(stamp + " " + tag + " " + one)
		levels.append(level)
		if file != null and file_bytes < MAX_FILE_BYTES:
			var out: String = plain[plain.size() - 1]
			file.store_line(out)
			file.flush()
			file_bytes += out.length() + 1
	if plain.size() > MAX_LINES:
		var cut := plain.size() - MAX_LINES
		plain = plain.slice(cut)
		levels = levels.slice(cut)
	if capture == null and not from_engine:
		print("[GameLog] ", text)
	dirty = true


func _process(delta: float) -> void:
	if capture != null:
		for item in capture.drain():
			_add(int(item[0]), String(item[1]), true)
	heartbeat_cd -= delta
	if heartbeat_cd <= 0.0:
		heartbeat_cd = HEARTBEAT_SEC
		var mem := Performance.get_monitor(Performance.MEMORY_STATIC) / 1048576.0
		var nodes := int(Performance.get_monitor(Performance.OBJECT_NODE_COUNT))
		_add(0, "heartbeat fps=%d mem=%.1fMB nodes=%d" % [Engine.get_frames_per_second(), mem, nodes])
	refresh_cd -= delta
	if dirty and panel != null and panel.visible and not show_prev and refresh_cd <= 0.0:
		refresh_cd = 0.4
		_refresh_view()


func _notification(what: int) -> void:
	match what:
		NOTIFICATION_WM_GO_BACK_REQUEST:
			_register_back()
		NOTIFICATION_APPLICATION_PAUSED:
			_add(0, "APP PAUSED (went to background)")
		NOTIFICATION_APPLICATION_RESUMED:
			_add(0, "APP RESUMED")
		NOTIFICATION_APPLICATION_FOCUS_IN:
			_add(0, "focus in")
		NOTIFICATION_APPLICATION_FOCUS_OUT:
			_add(0, "focus out")
		NOTIFICATION_CRASH:
			_add(2, "CRASH notification received")
		NOTIFICATION_OS_MEMORY_WARNING:
			_add(2, "OS LOW MEMORY WARNING")
		NOTIFICATION_WM_CLOSE_REQUEST:
			_add(0, "=== SESSION END (close request) ===")


func _input(event: InputEvent) -> void:
	if event is InputEventKey and event.pressed and not event.echo:
		var k := (event as InputEventKey).keycode
		if k == KEY_BACK or k == KEY_ESCAPE:
			_register_back()
		elif k == KEY_F1:
			_toggle_panel()


func _register_back() -> void:
	var now := Time.get_ticks_msec()
	var duplicate := now - _last_evt < DEDUPE_MS
	_last_evt = now
	if duplicate:
		return
	if panel != null and panel.visible:
		_hide_panel()
		_first_back = -100000
		return
	if now - _first_back <= DOUBLE_WINDOW_MS:
		_first_back = -100000
		_show_panel()
	else:
		_first_back = now


# ---------- UI ----------
func _toggle_panel() -> void:
	if panel != null and panel.visible:
		_hide_panel()
	else:
		_show_panel()


func _show_panel() -> void:
	if panel == null:
		_build_ui()
	show_prev = false
	_update_buttons()
	panel.visible = true
	_refresh_view(true)


func _hide_panel() -> void:
	if panel != null:
		panel.visible = false


func _make_button(label: String, callback: Callable) -> Button:
	var b := Button.new()
	b.text = label
	b.custom_minimum_size = Vector2(0, 52)
	b.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	b.add_theme_font_size_override("font_size", 18)
	b.pressed.connect(callback)
	return b


func _build_ui() -> void:
	layer = CanvasLayer.new()
	layer.layer = 200
	layer.process_mode = Node.PROCESS_MODE_ALWAYS
	add_child(layer)

	var bg := PanelContainer.new()
	bg.mouse_filter = Control.MOUSE_FILTER_STOP
	var sb := StyleBoxFlat.new()
	sb.bg_color = Color(0.03, 0.04, 0.06, 0.96)
	bg.add_theme_stylebox_override("panel", sb)
	layer.add_child(bg)
	bg.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	panel = bg

	var margin := MarginContainer.new()
	margin.add_theme_constant_override("margin_left", 16)
	margin.add_theme_constant_override("margin_right", 16)
	margin.add_theme_constant_override("margin_top", 12)
	margin.add_theme_constant_override("margin_bottom", 12)
	bg.add_child(margin)

	var vbox := VBoxContainer.new()
	vbox.add_theme_constant_override("separation", 8)
	margin.add_child(vbox)

	var title := Label.new()
	title.text = "GAME LOG  (Back = close)"
	title.add_theme_font_size_override("font_size", 22)
	vbox.add_child(title)

	var row := HBoxContainer.new()
	row.add_theme_constant_override("separation", 8)
	vbox.add_child(row)
	row.add_child(_make_button("COPY", _on_copy))
	row.add_child(_make_button("CLEAR", _on_clear))
	btn_filter = _make_button("ERRORS ONLY: OFF", _on_filter)
	row.add_child(btn_filter)
	btn_prev = _make_button("PREVIOUS SESSION", _on_prev)
	row.add_child(btn_prev)
	row.add_child(_make_button("TOP", _on_top))
	row.add_child(_make_button("BOTTOM", _on_bottom))
	row.add_child(_make_button("CLOSE", _hide_panel))

	status_label = Label.new()
	status_label.add_theme_font_size_override("font_size", 16)
	status_label.add_theme_color_override("font_color", Color(0.6, 0.7, 0.8))
	vbox.add_child(status_label)

	scroll = ScrollContainer.new()
	scroll.size_flags_vertical = Control.SIZE_EXPAND_FILL
	scroll.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	scroll.horizontal_scroll_mode = ScrollContainer.SCROLL_MODE_DISABLED
	vbox.add_child(scroll)

	rtl = RichTextLabel.new()
	rtl.bbcode_enabled = true
	rtl.fit_content = true
	rtl.scroll_active = false
	rtl.selection_enabled = false
	rtl.autowrap_mode = TextServer.AUTOWRAP_ARBITRARY
	rtl.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	rtl.add_theme_font_size_override("normal_font_size", 16)
	rtl.add_theme_font_size_override("mono_font_size", 16)
	scroll.add_child(rtl)

	panel.visible = false


func _update_buttons() -> void:
	if btn_filter != null:
		btn_filter.text = "ERRORS ONLY: " + ("ON" if errors_only else "OFF")
	if btn_prev != null:
		btn_prev.text = "CURRENT SESSION" if show_prev else "PREVIOUS SESSION"


func _color_for(level: int) -> String:
	if level == 2:
		return "#ff6b6b"
	if level == 1:
		return "#ffd166"
	return "#d0d8e0"


func _current_source() -> Array:
	if show_prev:
		return [prev_plain, prev_levels]
	return [plain, levels]


func _refresh_view(force_bottom: bool = false) -> void:
	if rtl == null:
		return
	dirty = false
	var src := _current_source()
	var p: Array = src[0]
	var lv: Array = src[1]
	var bar := scroll.get_v_scroll_bar()
	var at_bottom := force_bottom or bar.value >= bar.max_value - bar.page - 40.0
	var shown: Array[String] = []
	var i := p.size() - 1
	var count := 0
	var total_err := 0
	for l in lv:
		if int(l) == 2:
			total_err += 1
	while i >= 0 and count < SHOW_LINES:
		var level := int(lv[i])
		if not errors_only or level >= 1:
			var safe := String(p[i]).replace("[", "[lb]")
			shown.append("[color=%s]%s[/color]" % [_color_for(level), safe])
			count += 1
		i -= 1
	shown.reverse()
	rtl.text = "\n".join(shown)
	var src_name := "PREVIOUS" if show_prev else "CURRENT"
	status_label.text = "%s | total lines: %d | errors: %d | showing: %d" % [src_name, p.size(), total_err, count]
	if show_prev and p.is_empty():
		rtl.text = "[color=#ffd166]No previous session log found.[/color]"
	if at_bottom:
		await get_tree().process_frame
		await get_tree().process_frame
		scroll.scroll_vertical = int(bar.max_value)


func _on_copy() -> void:
	var src := _current_source()
	var p: Array = src[0]
	var text := "\n".join(PackedStringArray(p))
	if text.length() > COPY_MAX_CHARS:
		text = text.substr(text.length() - COPY_MAX_CHARS)
	DisplayServer.clipboard_set(text)
	status_label.text = "Copied %d characters to clipboard" % text.length()


func _on_clear() -> void:
	if show_prev:
		return
	plain.clear()
	levels.clear()
	_add(0, "--- log cleared ---")
	_refresh_view(true)


func _on_filter() -> void:
	errors_only = not errors_only
	_update_buttons()
	_refresh_view(true)


func _on_prev() -> void:
	show_prev = not show_prev
	if show_prev:
		_load_prev()
	_update_buttons()
	_refresh_view(true)


func _load_prev() -> void:
	prev_plain.clear()
	prev_levels.clear()
	if not FileAccess.file_exists(FILE_PREV):
		return
	var f := FileAccess.open(FILE_PREV, FileAccess.READ)
	if f == null:
		return
	var content := f.get_as_text()
	f.close()
	for l in content.split("\n"):
		var s := String(l)
		if s == "":
			continue
		var idx := s.find("] ")
		var level := 0
		if idx >= 0 and s.length() > idx + 2:
			var c := s[idx + 2]
			level = 2 if c == "E" else (1 if c == "W" else 0)
		prev_plain.append(s)
		prev_levels.append(level)


func _on_top() -> void:
	scroll.scroll_vertical = 0


func _on_bottom() -> void:
	scroll.scroll_vertical = int(scroll.get_v_scroll_bar().max_value)

extends Logger
# Engine-level error/print capture. Loaded dynamically by game_log.gd.

var _mutex := Mutex.new()
var _queue: Array = []


func _log_message(message: String, error: bool) -> void:
	var text := message.rstrip("\n")
	if text == "":
		return
	_mutex.lock()
	_queue.append([2 if error else 0, text])
	_mutex.unlock()


func _log_error(function: String, file: String, line: int, code: String, rationale: String, editor_notify: bool, error_type: int, script_backtraces: Array[ScriptBacktrace]) -> void:
	var level := 1 if error_type == 1 else 2
	var kind := "WARNING" if error_type == 1 else ("SCRIPT ERROR" if error_type == 2 else ("SHADER ERROR" if error_type == 3 else "ERROR"))
	var body := rationale if rationale != "" else code
	var text := "%s: %s\n   at %s:%d (%s)" % [kind, body, file, line, function]
	for bt in script_backtraces:
		if bt != null and not bt.is_empty():
			text += "\n" + bt.format()
	_mutex.lock()
	_queue.append([level, text])
	_mutex.unlock()


func drain() -> Array:
	_mutex.lock()
	var out := _queue.duplicate()
	_queue.clear()
	_mutex.unlock()
	return out
